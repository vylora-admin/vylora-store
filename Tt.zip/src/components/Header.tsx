'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import Icon from '@/components/ui/AppIcon';

const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [cartCount] = useState(2);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const navLinks = [
    { label: 'Collections', href: '/homepage#collections' },
    { label: 'Chains', href: '/homepage#chains' },
    { label: 'Rings', href: '/homepage#rings' },
    { label: 'Track Order', href: '/track-order' },
    { label: 'Wishlist', href: '/wishlist' },
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-primary/90 backdrop-blur-xl border-b border-white/5 py-3' :'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex items-center justify-between">
          {/* Logo */}
          <Link href="/homepage" className="flex items-center gap-2.5 group">
            <AppLogo
              size={32}
              className="transition-transform duration-300 group-hover:rotate-12"
            />
            <span className="font-display font-bold text-lg tracking-tight text-white hidden sm:block">
              JewelHub
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className="text-xs font-semibold uppercase tracking-[0.18em] text-white/50 hover:text-white transition-colors duration-300"
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 md:gap-3">
            <Link
              href="/dashboard"
              className="hidden md:flex items-center justify-center w-9 h-9 rounded-full hover:bg-white/5 transition-colors"
              aria-label="Account"
            >
              <Icon name="UserIcon" size={18} className="text-white/60 hover:text-white transition-colors" />
            </Link>

            <button
              className="relative flex items-center justify-center w-9 h-9 rounded-full hover:bg-white/5 transition-colors"
              aria-label="Cart"
              onClick={() => window.location.href = '/checkout'}
            >
              <Icon name="ShoppingBagIcon" size={18} className="text-white/60 hover:text-white transition-colors" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-white text-black text-[9px] font-bold rounded-full flex items-center justify-center font-mono">
                  {cartCount}
                </span>
              )}
            </button>

            <Link
              href="/login"
              className="hidden md:inline-flex btn-primary text-xs px-5 py-2.5 ml-2"
            >
              Sign In
            </Link>

            {/* Hamburger */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden flex items-center justify-center w-9 h-9 rounded-full border border-white/10 hover:border-white/30 transition-colors"
              aria-label="Toggle menu"
            >
              {mobileOpen
                ? <Icon name="XMarkIcon" size={18} className="text-white" />
                : <Icon name="Bars3Icon" size={18} className="text-white" />
              }
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Nav Overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 mobile-nav-backdrop flex flex-col pt-24 px-6 pb-10">
          <nav className="flex flex-col gap-1">
            {navLinks.map((link, i) => (
              <Link
                key={link.label}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="flex items-center justify-between py-4 border-b border-white/8 text-2xl font-semibold text-white tracking-tight hover:text-white/60 transition-colors"
                style={{ animationDelay: `${i * 0.05}s` }}
              >
                {link.label}
                <Icon name="ArrowRightIcon" size={20} className="text-white/30" />
              </Link>
            ))}
          </nav>

          <div className="mt-auto flex flex-col gap-3">
            <Link href="/dashboard" onClick={() => setMobileOpen(false)} className="btn-primary w-full text-center justify-center">
              My Account
            </Link>
            <Link href="/login" onClick={() => setMobileOpen(false)} className="btn-outline w-full text-center justify-center">
              Sign In
            </Link>
            <Link href="/register" onClick={() => setMobileOpen(false)} className="btn-outline w-full text-center justify-center">
              Create Account
            </Link>
          </div>
        </div>
      )}
    </>
  );
};

export default Header;