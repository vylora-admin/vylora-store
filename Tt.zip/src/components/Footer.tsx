import React from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import Icon from '@/components/ui/AppIcon';

const Footer: React.FC = () => {
  return (
    <footer className="border-t border-white/8 py-8 px-5 md:px-8 bg-primary">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-5">
        {/* Logo + Brand */}
        <Link href="/homepage" className="flex items-center gap-2.5 group">
          <AppLogo size={28} />
          <span className="font-display font-bold text-sm tracking-tight text-white/80">
            JewelHub
          </span>
        </Link>

        {/* Links */}
        <nav className="flex items-center flex-wrap justify-center gap-x-7 gap-y-2">
          {[
            { label: 'Collections', href: '/homepage#collections' },
            { label: 'Track Order', href: '/track-order' },
            { label: 'Dashboard', href: '/dashboard' },
            { label: 'Privacy', href: '/privacy' },
            { label: 'Terms', href: '/terms' },
          ].map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className="text-sm font-medium text-white/40 hover:text-white transition-colors duration-300"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Social + Copyright */}
        <div className="flex items-center gap-4">
          <a href="#" aria-label="Instagram" className="w-8 h-8 flex items-center justify-center rounded-full border border-white/10 hover:border-white/30 transition-colors">
            <Icon name="GlobeAltIcon" size={14} className="text-white/50" />
          </a>
          <a href="#" aria-label="Facebook" className="w-8 h-8 flex items-center justify-center rounded-full border border-white/10 hover:border-white/30 transition-colors">
            <Icon name="ChatBubbleLeftIcon" size={14} className="text-white/50" />
          </a>
          <span className="text-xs text-white/25 ml-2">© 2026 JewelHub</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;