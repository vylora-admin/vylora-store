'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1500);
  };

  return (
    <main className="bg-primary min-h-screen flex flex-col">
      <Header />
      <div className="flex-1 flex items-center justify-center px-5 py-28">
        <div className="w-full max-w-md">
          {/* Back link */}
          <Link
            href="/login"
            className="inline-flex items-center gap-2 text-white/40 hover:text-white text-xs font-semibold uppercase tracking-widest transition-colors mb-10"
          >
            <Icon name="ArrowLeftIcon" size={14} />
            Back to Sign In
          </Link>

          <div className="glass-panel rounded-3xl p-8 md:p-10">
            {!submitted ? (
              <>
                {/* Icon */}
                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6">
                  <Icon name="LockClosedIcon" size={24} className="text-white/60" />
                </div>

                <h1 className="font-display font-bold text-3xl text-white tracking-tight mb-2">
                  Forgot Password?
                </h1>
                <p className="text-white/40 text-sm mb-8 leading-relaxed">
                  No worries. Enter your email address and we&apos;ll send you a verification code to reset your password.
                </p>

                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-widest text-white/40 mb-2">
                      Email Address
                    </label>
                    <div className="relative">
                      <Icon name="EnvelopeIcon" size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="sara.ahmed@email.com"
                        className="w-full bg-white/5 border border-white/10 rounded-xl pl-11 pr-4 py-3.5 text-sm text-white placeholder-white/20 focus:outline-none focus:border-white/30 transition-colors"
                      />
                    </div>
                    {error && (
                      <p className="mt-2 text-xs text-red-400 flex items-center gap-1.5">
                        <Icon name="ExclamationCircleIcon" size={12} />
                        {error}
                      </p>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="btn-primary w-full py-3.5 text-sm flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        Send Reset Code
                        <Icon name="ArrowRightIcon" size={16} className="text-black" />
                      </>
                    )}
                  </button>
                </form>

                <p className="text-center text-white/30 text-xs mt-6">
                  Remember your password?{' '}
                  <Link href="/login" className="text-white hover:text-white/70 transition-colors font-semibold">
                    Sign In
                  </Link>
                </p>
              </>
            ) : (
              <>
                {/* Success state */}
                <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center mb-6">
                  <Icon name="CheckCircleIcon" size={24} className="text-white" />
                </div>
                <h1 className="font-display font-bold text-3xl text-white tracking-tight mb-2">
                  Check Your Email
                </h1>
                <p className="text-white/40 text-sm mb-2 leading-relaxed">
                  We&apos;ve sent a 6-digit verification code to
                </p>
                <p className="text-white font-semibold text-sm mb-8">{email}</p>

                <Link
                  href="/otp-verification"
                  className="btn-primary w-full py-3.5 text-sm flex items-center justify-center gap-2"
                >
                  Enter Verification Code
                  <Icon name="ArrowRightIcon" size={16} className="text-black" />
                </Link>

                <button
                  onClick={() => setSubmitted(false)}
                  className="w-full mt-3 py-3 text-xs text-white/40 hover:text-white transition-colors"
                >
                  Use a different email
                </button>
              </>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
