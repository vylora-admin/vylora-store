import React from 'react';
import Header from '@/components/Header';
import LoginForm from '@/app/login/components/LoginForm';
import LoginVisual from '@/app/login/components/LoginVisual';

export default function LoginPage() {
  return (
    <main className="bg-primary min-h-screen overflow-hidden">
      <Header />
      <div className="min-h-screen grid grid-cols-1 lg:grid-cols-2">
        <LoginVisual />
        <LoginForm />
      </div>
    </main>
  );
}