'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import Icon from '@/components/ui/AppIcon';

const LoginForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});

  const validate = () => {
    const newErrors: { email?: string; password?: string } = {};
    if (!email) newErrors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) newErrors.email = 'Enter a valid email';
    if (!password) newErrors.password = 'Password is required';
    else if (password.length < 6) newErrors.password = 'Minimum 6 characters';
    return newErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }
    setErrors({});
    setLoading(true);
    // Mock submit — connect to auth backend here
    setTimeout(() => setLoading(false), 1500);
  };

  return (
    <div className="flex flex-col justify-center px-6 md:px-12 lg:px-16 py-24 lg:py-0 bg-primary min-h-screen lg:min-h-0">
      <div className="max-w-md w-full mx-auto">
        {/* Logo */}
        <Link href="/homepage" className="flex items-center gap-2.5 mb-10 group w-fit">
          <AppLogo size={36} />
          <span className="font-display font-bold text-lg tracking-tight text-white">JewelHub</span>
        </Link>

        {/* Heading */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-white mb-2">Welcome back</h1>
          <p className="text-sm text-white/40 font-light">
            Sign in to your account or{' '}
            <Link href="/homepage" className="text-white/70 hover:text-white underline underline-offset-2 transition-colors">
              continue as guest
            </Link>
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} noValidate className="space-y-6">
          {/* Email */}
          <div>
            <label className="block text-[11px] uppercase tracking-ultra text-white/40 mb-2">
              Email Address
            </label>
            <div className="relative">
              <input
                type="email"
                value={email}
                onChange={(e) => { setEmail(e.target.value); setErrors((prev) => ({ ...prev, email: undefined })); }}
                placeholder="your@email.com"
                className={`input-field pr-10 ${errors.email ? 'border-red-500/60' : ''}`}
                autoComplete="email"
              />
              <Icon name="EnvelopeIcon" size={16} className="absolute right-0 top-1/2 -translate-y-1/2 text-white/20" />
            </div>
            {errors.email && (
              <p className="text-[11px] text-red-400 mt-1.5 flex items-center gap-1">
                <Icon name="ExclamationCircleIcon" size={12} className="text-red-400" />
                {errors.email}
              </p>
            )}
          </div>

          {/* Password */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-[11px] uppercase tracking-ultra text-white/40">
                Password
              </label>
              <button type="button" className="text-[11px] text-white/40 hover:text-white transition-colors">
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => { setPassword(e.target.value); setErrors((prev) => ({ ...prev, password: undefined })); }}
                placeholder="••••••••"
                className={`input-field pr-10 ${errors.password ? 'border-red-500/60' : ''}`}
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-0 top-1/2 -translate-y-1/2 text-white/20 hover:text-white/50 transition-colors"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                <Icon name={showPassword ? 'EyeSlashIcon' : 'EyeIcon'} size={16} />
              </button>
            </div>
            {errors.password && (
              <p className="text-[11px] text-red-400 mt-1.5 flex items-center gap-1">
                <Icon name="ExclamationCircleIcon" size={12} className="text-red-400" />
                {errors.password}
              </p>
            )}
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="w-full btn-primary justify-center py-4 rounded-xl text-sm mt-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <>
                <Icon name="ArrowPathIcon" size={16} className="animate-spin" />
                Signing in...
              </>
            ) : (
              <>
                Sign In
                <Icon name="ArrowRightIcon" size={16} />
              </>
            )}
          </button>
        </form>

        {/* Divider */}
        <div className="flex items-center gap-4 my-6">
          <div className="flex-1 h-px bg-white/8" />
          <span className="text-[11px] text-white/25 uppercase tracking-widest">or</span>
          <div className="flex-1 h-px bg-white/8" />
        </div>

        {/* Guest checkout */}
        <Link
          href="/homepage"
          className="w-full btn-outline justify-center py-4 rounded-xl text-sm flex items-center gap-2"
        >
          <Icon name="ShoppingBagIcon" size={16} />
          Continue as Guest
        </Link>

        {/* Register link */}
        <p className="text-center text-sm text-white/35 mt-6">
          Don&apos;t have an account?{' '}
          <Link href="/register" className="text-white font-semibold hover:text-white/70 transition-colors">
            Create one
          </Link>
        </p>

        {/* Trust note */}
        <div className="mt-8 pt-6 border-t border-white/8 flex items-center justify-center gap-2">
          <Icon name="LockClosedIcon" size={12} className="text-white/20" />
          <span className="text-[11px] text-white/25">Secured with 256-bit encryption</span>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;