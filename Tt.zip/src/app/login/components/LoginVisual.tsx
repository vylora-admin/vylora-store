import React from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

const LoginVisual: React.FC = () => {
  return (
    <div className="hidden lg:flex relative overflow-hidden">
      {/* Background image */}
      <AppImage
        src="https://images.unsplash.com/photo-1680113729613-7635a0b8be09"
        alt="Luxury jewelry flat lay on black marble, rings and chains arranged artistically, deep shadow moody atmosphere"
        fill
        priority
        className="object-cover"
        sizes="50vw" />
      
      {/* Scrim */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-black/30" />
      <div className="absolute inset-0 bg-black/30" />

      {/* Content overlay */}
      <div className="relative z-10 flex flex-col justify-between p-12 w-full">
        {/* Top badge */}
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-white/60" />
          <span className="text-[11px] uppercase tracking-ultra text-white/50 font-semibold">JewelHub Egypt</span>
        </div>

        {/* Quote */}
        <div className="max-w-sm">
          <Icon name="ChatBubbleLeftRightIcon" size={32} className="text-white/20 mb-5" />
          <blockquote className="text-2xl font-light italic text-white/80 leading-relaxed mb-5">
            &ldquo;Jewelry is the most personal form of self-expression. Find yours.&rdquo;
          </blockquote>
          <div className="flex items-center gap-3">
            <div className="h-px w-8 bg-white/30" />
            <span className="text-xs text-white/40 uppercase tracking-widest">JewelHub</span>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-8 pt-8 border-t border-white/10">
            {[
            { v: '12K+', l: 'Customers' },
            { v: '500+', l: 'Designs' },
            { v: '4.9★', l: 'Rating' }].
            map((s) =>
            <div key={s.l}>
                <div className="text-xl font-bold font-mono-custom text-white">{s.v}</div>
                <div className="text-[10px] text-white/35 uppercase tracking-widest mt-0.5">{s.l}</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>);

};

export default LoginVisual;