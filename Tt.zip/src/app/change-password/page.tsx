'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

function getStrength(password: string): { score: number; label: string; color: string } {
  let score = 0;
  if (password.length >= 8) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  if (score <= 1) return { score, label: 'Weak', color: 'bg-red-500' };
  if (score === 2) return { score, label: 'Fair', color: 'bg-yellow-500' };
  if (score === 3) return { score, label: 'Good', color: 'bg-blue-400' };
  return { score, label: 'Strong', color: 'bg-green-400' };
}

export default function ChangePasswordPage() {
  const [form, setForm] = useState({ newPassword: '', confirmPassword: '' });
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [changed, setChanged] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const strength = getStrength(form.newPassword);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!form.newPassword) errs.newPassword = 'Password is required.';
    else if (form.newPassword.length < 8) errs.newPassword = 'Password must be at least 8 characters.';
    if (!form.confirmPassword) errs.confirmPassword = 'Please confirm your password.';
    else if (form.newPassword !== form.confirmPassword) errs.confirmPassword = 'Passwords do not match.';
    return errs;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setChanged(true);
    }, 1500);
  };

  return (
    <main className="bg-primary min-h-screen flex flex-col">
      <Header />
      <div className="flex-1 flex items-center justify-center px-5 py-28">
        <div className="w-full max-w-md">
          <Link
            href="/otp-verification"
            className="inline-flex items-center gap-2 text-white/40 hover:text-white text-xs font-semibold uppercase tracking-widest transition-colors mb-10"
          >
            <Icon name="ArrowLeftIcon" size={14} />
            Back
          </Link>

          <div className="glass-panel rounded-3xl p-8 md:p-10">
            {!changed ? (
              <>
                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6">
                  <Icon name="KeyIcon" size={24} className="text-white/60" />
                </div>

                <h1 className="font-display font-bold text-3xl text-white tracking-tight mb-2">
                  Set New Password
                </h1>
                <p className="text-white/40 text-sm mb-8 leading-relaxed">
                  Create a strong password for your JewelHub account. Use at least 8 characters with a mix of letters, numbers, and symbols.
                </p>

                <form onSubmit={handleSubmit} className="space-y-5">
                  {/* New Password */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-widest text-white/40 mb-2">
                      New Password
                    </label>
                    <div className="relative">
                      <Icon name="LockClosedIcon" size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
                      <input
                        type={showNew ? 'text' : 'password'}
                        value={form.newPassword}
                        onChange={(e) => {
                          setForm((prev) => ({ ...prev, newPassword: e.target.value }));
                          setErrors((prev) => ({ ...prev, newPassword: '' }));
                        }}
                        placeholder="Enter new password"
                        className={`w-full bg-white/5 border rounded-xl pl-11 pr-11 py-3.5 text-sm text-white placeholder-white/20 focus:outline-none transition-colors ${
                          errors.newPassword ? 'border-red-400/50' : 'border-white/10 focus:border-white/30'
                        }`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowNew(!showNew)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
                      >
                        <Icon name={showNew ? 'EyeSlashIcon' : 'EyeIcon'} size={16} />
                      </button>
                    </div>
                    {errors.newPassword && (
                      <p className="mt-1.5 text-xs text-red-400 flex items-center gap-1.5">
                        <Icon name="ExclamationCircleIcon" size={12} />
                        {errors.newPassword}
                      </p>
                    )}

                    {/* Strength bar */}
                    {form.newPassword.length > 0 && (
                      <div className="mt-3">
                        <div className="flex gap-1 mb-1.5">
                          {[1, 2, 3, 4].map((i) => (
                            <div
                              key={i}
                              className={`h-1 flex-1 rounded-full transition-all duration-300 ${
                                i <= strength.score ? strength.color : 'bg-white/10'
                              }`}
                            />
                          ))}
                        </div>
                        <p className="text-xs text-white/40">
                          Password strength:{' '}
                          <span className="text-white/70 font-semibold">{strength.label}</span>
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Confirm Password */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-widest text-white/40 mb-2">
                      Confirm Password
                    </label>
                    <div className="relative">
                      <Icon name="LockClosedIcon" size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
                      <input
                        type={showConfirm ? 'text' : 'password'}
                        value={form.confirmPassword}
                        onChange={(e) => {
                          setForm((prev) => ({ ...prev, confirmPassword: e.target.value }));
                          setErrors((prev) => ({ ...prev, confirmPassword: '' }));
                        }}
                        placeholder="Confirm new password"
                        className={`w-full bg-white/5 border rounded-xl pl-11 pr-11 py-3.5 text-sm text-white placeholder-white/20 focus:outline-none transition-colors ${
                          errors.confirmPassword ? 'border-red-400/50' : 'border-white/10 focus:border-white/30'
                        }`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirm(!showConfirm)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
                      >
                        <Icon name={showConfirm ? 'EyeSlashIcon' : 'EyeIcon'} size={16} />
                      </button>
                    </div>
                    {errors.confirmPassword && (
                      <p className="mt-1.5 text-xs text-red-400 flex items-center gap-1.5">
                        <Icon name="ExclamationCircleIcon" size={12} />
                        {errors.confirmPassword}
                      </p>
                    )}
                    {form.confirmPassword && !errors.confirmPassword && form.newPassword === form.confirmPassword && (
                      <p className="mt-1.5 text-xs text-green-400 flex items-center gap-1.5">
                        <Icon name="CheckCircleIcon" size={12} />
                        Passwords match
                      </p>
                    )}
                  </div>

                  {/* Requirements */}
                  <div className="bg-white/3 border border-white/8 rounded-xl p-4 space-y-2">
                    {[
                      { label: 'At least 8 characters', met: form.newPassword.length >= 8 },
                      { label: 'One uppercase letter', met: /[A-Z]/.test(form.newPassword) },
                      { label: 'One number', met: /[0-9]/.test(form.newPassword) },
                      { label: 'One special character', met: /[^A-Za-z0-9]/.test(form.newPassword) },
                    ].map((req) => (
                      <div key={req.label} className="flex items-center gap-2">
                        <Icon
                          name={req.met ? 'CheckCircleIcon' : 'XCircleIcon'}
                          size={14}
                          className={req.met ? 'text-green-400' : 'text-white/20'}
                        />
                        <span className={`text-xs ${req.met ? 'text-white/60' : 'text-white/25'}`}>{req.label}</span>
                      </div>
                    ))}
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="btn-primary w-full py-3.5 text-sm flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                        Updating...
                      </>
                    ) : (
                      <>
                        Update Password
                        <Icon name="ArrowRightIcon" size={16} className="text-black" />
                      </>
                    )}
                  </button>
                </form>
              </>
            ) : (
              <>
                <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center mb-6">
                  <Icon name="CheckCircleIcon" size={24} className="text-white" />
                </div>
                <h1 className="font-display font-bold text-3xl text-white tracking-tight mb-2">
                  Password Updated!
                </h1>
                <p className="text-white/40 text-sm mb-8 leading-relaxed">
                  Your password has been successfully changed. You can now sign in with your new password.
                </p>
                <Link
                  href="/login"
                  className="btn-primary w-full py-3.5 text-sm flex items-center justify-center gap-2"
                >
                  Sign In Now
                  <Icon name="ArrowRightIcon" size={16} className="text-black" />
                </Link>
                <Link
                  href="/homepage"
                  className="block text-center mt-3 py-3 text-xs text-white/40 hover:text-white transition-colors"
                >
                  Back to Home
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
