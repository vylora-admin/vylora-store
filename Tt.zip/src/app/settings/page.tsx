'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

const settingsTabs = ['Profile', 'Security', 'Notifications', 'Preferences'];

interface ToggleProps {
  enabled: boolean;
  onChange: () => void;
}

function Toggle({ enabled, onChange }: ToggleProps) {
  return (
    <button
      onClick={onChange}
      className={`relative w-11 h-6 rounded-full transition-all duration-300 ${enabled ? 'bg-white' : 'bg-white/10 border border-white/15'}`}
    >
      <div className={`absolute top-0.5 w-5 h-5 rounded-full transition-all duration-300 ${enabled ? 'left-[22px] bg-black' : 'left-0.5 bg-white/40'}`} />
    </button>
  );
}

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('Profile');
  const [notifications, setNotifications] = useState({
    orderUpdates: true,
    promotions: false,
    newArrivals: true,
    sms: false,
    whatsapp: true,
  });
  const [profile, setProfile] = useState({
    firstName: 'Sara',
    lastName: 'Ahmed',
    email: 'sara.ahmed@email.com',
    phone: '+20 100 123 4567',
    birthdate: '1995-06-15',
  });
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const toggleNotif = (key: keyof typeof notifications) => {
    setNotifications((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <main className="bg-primary min-h-screen">
      <Header />
      <div className="pt-28 pb-20 px-5 md:px-8 max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-10">
          <p className="section-label mb-3">Account</p>
          <h1 className="font-display font-bold text-4xl md:text-5xl text-white tracking-tight">Settings</h1>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="md:col-span-1">
            <nav className="space-y-1">
              {settingsTabs.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-300 text-left ${
                    activeTab === tab
                      ? 'bg-white text-black' :'text-white/40 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon
                    name={
                      tab === 'Profile' ? 'UserIcon' :
                      tab === 'Security' ? 'ShieldCheckIcon' :
                      tab === 'Notifications'? 'BellIcon' : 'AdjustmentsHorizontalIcon'
                    }
                    size={16}
                  />
                  {tab}
                </button>
              ))}
              <div className="pt-4 mt-4 border-t border-white/8">
                <Link
                  href="/dashboard"
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-white/30 hover:text-white hover:bg-white/5 transition-all duration-300"
                >
                  <Icon name="ArrowLeftIcon" size={16} />
                  Back to Dashboard
                </Link>
              </div>
            </nav>
          </div>

          {/* Content */}
          <div className="md:col-span-3">
            {activeTab === 'Profile' && (
              <div className="glass-panel rounded-2xl p-6 md:p-8">
                <h2 className="font-display font-semibold text-white text-xl mb-6">Personal Information</h2>

                {/* Avatar */}
                <div className="flex items-center gap-5 mb-8 pb-8 border-b border-white/8">
                  <div className="w-16 h-16 rounded-full bg-white/10 border border-white/20 flex items-center justify-center">
                    <Icon name="UserIcon" size={28} className="text-white/40" />
                  </div>
                  <div>
                    <button className="btn-outline text-xs px-4 py-2">Change Photo</button>
                    <p className="text-xs text-white/30 mt-1.5">JPG, PNG up to 5MB</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-5 mb-5">
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-2">First Name</label>
                    <input
                      value={profile.firstName}
                      onChange={(e) => setProfile({ ...profile, firstName: e.target.value })}
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-2">Last Name</label>
                    <input
                      value={profile.lastName}
                      onChange={(e) => setProfile({ ...profile, lastName: e.target.value })}
                      className="input-field"
                    />
                  </div>
                </div>
                <div className="mb-5">
                  <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-2">Email Address</label>
                  <input
                    type="email"
                    value={profile.email}
                    onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                    className="input-field"
                  />
                </div>
                <div className="mb-5">
                  <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-2">Phone Number</label>
                  <input
                    value={profile.phone}
                    onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                    className="input-field"
                  />
                </div>
                <div className="mb-8">
                  <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-2">Date of Birth</label>
                  <input
                    type="date"
                    value={profile.birthdate}
                    onChange={(e) => setProfile({ ...profile, birthdate: e.target.value })}
                    className="input-field"
                  />
                </div>
                <button onClick={handleSave} className="btn-primary">
                  {saved ? <><Icon name="CheckIcon" size={16} /> Saved!</> : 'Save Changes'}
                </button>
              </div>
            )}

            {activeTab === 'Security' && (
              <div className="space-y-4">
                <div className="glass-panel rounded-2xl p-6 md:p-8">
                  <h2 className="font-display font-semibold text-white text-xl mb-6">Change Password</h2>
                  <div className="space-y-5">
                    <div>
                      <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-2">Current Password</label>
                      <input type="password" placeholder="••••••••" className="input-field" />
                    </div>
                    <div>
                      <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-2">New Password</label>
                      <input type="password" placeholder="••••••••" className="input-field" />
                    </div>
                    <div>
                      <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-2">Confirm New Password</label>
                      <input type="password" placeholder="••••••••" className="input-field" />
                    </div>
                    <button className="btn-primary">Update Password</button>
                  </div>
                </div>

                <div className="glass-panel rounded-2xl p-6 md:p-8">
                  <h2 className="font-display font-semibold text-white text-xl mb-2">Two-Factor Authentication</h2>
                  <p className="text-sm text-white/40 mb-5">Add an extra layer of security to your account.</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Icon name="DevicePhoneMobileIcon" size={20} className="text-white/40" />
                      <div>
                        <p className="text-sm font-semibold text-white">SMS Authentication</p>
                        <p className="text-xs text-white/30">+20 100 *** 4567</p>
                      </div>
                    </div>
                    <button className="btn-outline text-xs px-4 py-2">Enable</button>
                  </div>
                </div>

                <div className="glass-panel rounded-2xl p-6 border border-red-500/10">
                  <h2 className="font-display font-semibold text-white text-xl mb-2">Danger Zone</h2>
                  <p className="text-sm text-white/40 mb-5">Permanently delete your account and all associated data.</p>
                  <button className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-red-500/30 text-red-400 text-xs font-semibold hover:bg-red-500/10 transition-colors">
                    <Icon name="TrashIcon" size={14} />
                    Delete Account
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'Notifications' && (
              <div className="glass-panel rounded-2xl p-6 md:p-8">
                <h2 className="font-display font-semibold text-white text-xl mb-6">Notification Preferences</h2>
                <div className="space-y-0">
                  {[
                    { key: 'orderUpdates' as const, label: 'Order Updates', desc: 'Shipping, delivery, and status changes' },
                    { key: 'promotions' as const, label: 'Promotions & Offers', desc: 'Exclusive deals and seasonal sales' },
                    { key: 'newArrivals' as const, label: 'New Arrivals', desc: 'Be the first to know about new collections' },
                    { key: 'sms' as const, label: 'SMS Notifications', desc: 'Receive updates via text message' },
                    { key: 'whatsapp' as const, label: 'WhatsApp Notifications', desc: 'Receive updates via WhatsApp' },
                  ].map((item, i, arr) => (
                    <div key={item.key} className={`flex items-center justify-between py-5 ${i < arr.length - 1 ? 'border-b border-white/8' : ''}`}>
                      <div>
                        <p className="text-sm font-semibold text-white">{item.label}</p>
                        <p className="text-xs text-white/40 mt-0.5">{item.desc}</p>
                      </div>
                      <Toggle enabled={notifications[item.key]} onChange={() => toggleNotif(item.key)} />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'Preferences' && (
              <div className="glass-panel rounded-2xl p-6 md:p-8">
                <h2 className="font-display font-semibold text-white text-xl mb-6">App Preferences</h2>
                <div className="space-y-6">
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-3">Currency</label>
                    <div className="flex gap-2">
                      {['EGP', 'USD', 'EUR'].map((c) => (
                        <button key={c} className={`px-4 py-2 rounded-full text-xs font-semibold border transition-all ${c === 'EGP' ? 'bg-white text-black border-white' : 'border-white/15 text-white/40 hover:border-white/30'}`}>
                          {c}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-3">Language</label>
                    <div className="flex gap-2">
                      {['English', 'العربية'].map((l) => (
                        <button key={l} className={`px-4 py-2 rounded-full text-xs font-semibold border transition-all ${l === 'English' ? 'bg-white text-black border-white' : 'border-white/15 text-white/40 hover:border-white/30'}`}>
                          {l}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="pt-4 border-t border-white/8">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-semibold text-white">Dark Mode</p>
                        <p className="text-xs text-white/40 mt-0.5">Always on — part of the JewelHub experience</p>
                      </div>
                      <div className="w-11 h-6 rounded-full bg-white flex items-center justify-end pr-0.5">
                        <div className="w-5 h-5 rounded-full bg-black" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}