'use client';

import React, { useState, useRef } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from '@/app/homepage/components/HeroSection';
import CollectionsBento from '@/app/homepage/components/CollectionsBento';
import WhyJewelHub from '@/app/homepage/components/WhyJewelHub';
import BestsellersSection from '@/app/homepage/components/BestsellersSection';
import TestimonialsSection from '@/app/homepage/components/TestimonialsSection';
import PromoBanner from '@/app/homepage/components/PromoBanner';
import AdsBanner from '@/app/homepage/components/AdsBanner';

export default function Homepage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const productsSectionRef = useRef<HTMLDivElement>(null);

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setTimeout(() => {
      productsSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 50);
  };

  return (
    <main className="bg-primary min-h-screen overflow-x-hidden">
      <Header />
      <HeroSection />
      <PromoBanner />
      <AdsBanner />
      <CollectionsBento onCategorySelect={handleCategorySelect} selectedCategory={selectedCategory} />
      <WhyJewelHub />
      <div ref={productsSectionRef}>
        <BestsellersSection selectedCategory={selectedCategory} onCategoryChange={setSelectedCategory} />
      </div>
      <TestimonialsSection />
      <Footer />
    </main>
  );
}