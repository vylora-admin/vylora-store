'use client';

import React, { useEffect, useRef } from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

interface CollectionCard {
  id: string;
  title: string;
  subtitle: string;
  count: number;
  image: string;
  alt: string;
  colSpan: string;
  rowSpan?: string;
  height: string;
}

interface CollectionsBentoProps {
  onCategorySelect?: (categoryId: string) => void;
  selectedCategory?: string;
}

// Bento grid row audit (4-col grid):
// Row 1: [Chains col-span-2] + [Rings col-span-1] + [Earrings col-span-1] = 4/4 ✓
// Row 2: [Hand Acc col-span-1] + [New Arrivals col-span-3] = 4/4 ✓

const collections: CollectionCard[] = [
{
  id: 'chains',
  title: 'Chains',
  subtitle: 'Layered & Statement',
  count: 84,
  image: "https://images.unsplash.com/photo-1653587892907-4b9a7822ceba",
  alt: 'Delicate gold chain necklace on black velvet, close-up studio shot, dark moody background',
  colSpan: 'col-span-2',
  height: 'h-72 md:h-96'
},
{
  id: 'rings',
  title: 'Rings',
  subtitle: 'Stackable & Solitaire',
  count: 62,
  image: "https://images.unsplash.com/photo-1696146217980-e64923d0f5be",
  alt: 'Silver ring with gemstone on dark stone surface, dim atmospheric lighting',
  colSpan: 'col-span-1',
  height: 'h-72 md:h-96'
},
{
  id: 'earrings',
  title: 'Earrings',
  subtitle: 'Hoops & Drops',
  count: 91,
  image: "https://images.unsplash.com/photo-1617038220319-276d3cfab638",
  alt: 'Gold hoop earrings hanging against deep shadow background, editorial jewelry photography',
  colSpan: 'col-span-1',
  height: 'h-72 md:h-96'
},
{
  id: 'hand',
  title: 'Hand Accessories',
  subtitle: 'Bracelets & Cuffs',
  count: 47,
  image: "https://images.unsplash.com/photo-1619525673983-81151d6cc193",
  alt: 'Gold bracelet on wrist against dark background, moody atmospheric lighting',
  colSpan: 'col-span-1',
  height: 'h-56 md:h-72'
},
{
  id: 'new',
  title: 'New Arrivals',
  subtitle: 'Just landed — Spring 2026',
  count: 38,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1156adfd8-1767353505898.png",
  alt: 'Assorted jewelry collection arranged on dark marble, dramatic side lighting, deep shadows',
  colSpan: 'col-span-3',
  height: 'h-56 md:h-72'
}];


const CollectionsBento: React.FC<CollectionsBentoProps> = ({ onCategorySelect, selectedCategory }) => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll('.scroll-reveal');
            elements.forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 100);
            });
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const handleCardClick = (e: React.MouseEvent, colId: string) => {
    e.preventDefault();
    if (onCategorySelect) {
      onCategorySelect(colId === selectedCategory ? 'all' : colId);
    }
  };

  return (
    <section id="collections" ref={sectionRef} className="py-20 md:py-28 px-5 md:px-8 bg-primary">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-5 mb-10 scroll-reveal">
          <div>
            <span className="section-label block mb-3">Shop by Category</span>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-white">
              Our Collections
            </h2>
          </div>
          <button
            onClick={() => onCategorySelect?.('all')}
            className="inline-flex items-center gap-2 text-sm font-semibold text-white/50 hover:text-white transition-colors uppercase tracking-widest">
            View All
            <Icon name="ArrowRightIcon" size={16} />
          </button>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {collections.map((col, i) => {
            const isSelected = selectedCategory === col.id;
            return (
              <button
                key={col.id}
                onClick={(e) => handleCardClick(e, col.id)}
                className={`${col.colSpan} relative overflow-hidden rounded-xl3 group cursor-pointer scroll-reveal stagger-${Math.min(i + 1, 4)} hover-lift text-left transition-all duration-300 ${isSelected ? 'ring-2 ring-white ring-offset-2 ring-offset-black' : ''}`}>
                <div className={`${col.height} relative overflow-hidden`}>
                  <AppImage
                    src={col.image}
                    alt={col.alt}
                    fill
                    className="object-cover product-card-img img-grayscale"
                    sizes="(max-width: 768px) 50vw, 25vw" />

                  {/* Gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                  {/* Selected indicator */}
                  {isSelected && (
                    <div className="absolute top-3 left-3 bg-white text-black text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full">
                      Selected
                    </div>
                  )}

                  {/* Content */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 md:p-5">
                    <div className="flex items-end justify-between">
                      <div>
                        <h3 className="text-lg md:text-xl font-bold text-white tracking-tight">{col.title}</h3>
                        <p className="text-xs text-white/50 mt-0.5">{col.subtitle}</p>
                      </div>
                      <div className="glass-panel px-2.5 py-1 rounded-full">
                        <span className="text-[11px] font-mono-custom text-white/70">{col.count}</span>
                      </div>
                    </div>
                  </div>

                  {/* Hover arrow */}
                  <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/0 flex items-center justify-center transition-all duration-300 group-hover:bg-white/15">
                    <Icon name="ArrowUpRightIcon" size={14} className="text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default CollectionsBento;