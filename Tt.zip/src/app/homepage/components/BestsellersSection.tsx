'use client';

import React, { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

interface Product {
  id: string;
  name: string;
  category: string;
  categoryId: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  alt: string;
  badge?: string;
  variants: string[];
  sizes: string[];
  stock: number;
  inStock: boolean;
}

const products: Product[] = [
{
  id: 'p1',
  name: 'Cairo Layered Chain',
  category: 'Chains',
  categoryId: 'chains',
  price: 850,
  originalPrice: 1100,
  rating: 4.9,
  reviews: 284,
  image: "https://images.unsplash.com/photo-1659806403702-93c3fb3f5502",
  alt: 'Layered gold chain necklace on black velvet display, dark studio background',
  badge: 'Bestseller',
  variants: ['Gold', 'Silver', 'Rose Gold'],
  sizes: ['40cm', '45cm', '50cm'],
  stock: 8,
  inStock: true
},
{
  id: 'p2',
  name: 'Nile Solitaire Ring',
  category: 'Rings',
  categoryId: 'rings',
  price: 620,
  rating: 4.8,
  reviews: 157,
  image: "https://images.unsplash.com/photo-1696146218123-1b0ee837536d",
  alt: 'Minimalist silver ring with small stone on dark marble, dim moody lighting',
  badge: 'New',
  variants: ['Silver', 'Gold'],
  sizes: ['5', '6', '7', '8', '9'],
  stock: 3,
  inStock: true
},
{
  id: 'p3',
  name: 'Alexandria Hoop Earrings',
  category: 'Earrings',
  categoryId: 'earrings',
  price: 490,
  originalPrice: 650,
  rating: 4.7,
  reviews: 203,
  image: "https://images.unsplash.com/photo-1602584303280-ff3d124b7e5e",
  alt: 'Gold hoop earrings hanging on dark background, editorial studio photography',
  variants: ['Gold', 'Silver'],
  sizes: ['Small', 'Medium', 'Large'],
  stock: 12,
  inStock: true
},
{
  id: 'p4',
  name: 'Pharaoh Cuff Bracelet',
  category: 'Hand Accessories',
  categoryId: 'hand',
  price: 730,
  rating: 4.9,
  reviews: 98,
  image: "https://images.unsplash.com/photo-1619525673983-81151d6cc193",
  alt: 'Wide gold cuff bracelet on wrist, dark atmospheric background, dramatic lighting',
  badge: 'Limited',
  variants: ['Gold', 'Silver', 'Black'],
  sizes: ['S', 'M', 'L'],
  stock: 0,
  inStock: false
},
{
  id: 'p5',
  name: 'Luxor Stacking Ring Set',
  category: 'Rings',
  categoryId: 'rings',
  price: 540,
  rating: 4.8,
  reviews: 112,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1686db1df-1772155711323.png",
  alt: 'Set of three gold stacking rings on dark surface, minimalist jewelry photography',
  badge: 'New',
  variants: ['Gold', 'Silver'],
  sizes: ['5', '6', '7', '8'],
  stock: 5,
  inStock: true
},
{
  id: 'p6',
  name: 'Cleopatra Drop Earrings',
  category: 'Earrings',
  categoryId: 'earrings',
  price: 380,
  rating: 4.6,
  reviews: 89,
  image: "https://images.unsplash.com/photo-1700575668928-30a9091b1d4a",
  alt: 'Long drop earrings with gold detail on dark background, editorial photography',
  variants: ['Gold', 'Silver'],
  sizes: ['One Size'],
  stock: 20,
  inStock: true
},
{
  id: 'p7',
  name: 'Nile Delicate Chain',
  category: 'Chains',
  categoryId: 'chains',
  price: 460,
  originalPrice: 580,
  rating: 4.7,
  reviews: 143,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1731b90b3-1772212856363.png",
  alt: 'Delicate thin gold chain necklace on dark velvet, close-up product shot',
  variants: ['Gold', 'Silver', 'Rose Gold'],
  sizes: ['40cm', '45cm', '50cm', '55cm'],
  stock: 2,
  inStock: true
},
{
  id: 'p8',
  name: 'Isis Bangle Set',
  category: 'Hand Accessories',
  categoryId: 'hand',
  price: 590,
  rating: 4.8,
  reviews: 76,
  image: "https://images.unsplash.com/photo-1515307057056-f652cdc570b7",
  alt: 'Set of gold bangles on wrist against dark background, luxury jewelry photography',
  badge: 'Bestseller',
  variants: ['Gold', 'Silver'],
  sizes: ['S', 'M', 'L', 'XL'],
  stock: 7,
  inStock: true
}];


const categoryTabs = [
{ id: 'all', label: 'View All' },
{ id: 'rings', label: 'Rings' },
{ id: 'earrings', label: 'Earrings' },
{ id: 'chains', label: 'Chains' },
{ id: 'hand', label: 'Hand Accessories' }];


interface BestsellersSectionProps {
  selectedCategory?: string;
  onCategoryChange?: (categoryId: string) => void;
}

interface ProductCardProps {
  product: Product;
  index: number;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, index }) => {
  const [selectedVariant, setSelectedVariant] = useState(0);
  const [selectedSize, setSelectedSize] = useState(0);
  const [wishlisted, setWishlisted] = useState(false);

  const stockLabel = product.stock === 0 ? 'Out of Stock' : product.stock <= 3 ? `Only ${product.stock} left` : `${product.stock} in stock`;
  const stockColor = product.stock === 0 ? 'text-white/30' : product.stock <= 3 ? 'text-amber-400/80' : 'text-white/50';

  return (
    <div className={`product-card group scroll-reveal stagger-${Math.min(index + 1, 4)}`}>
      {/* Image container */}
      <div className="relative overflow-hidden rounded-xl2 mb-4 bg-tertiary">
        <div className="aspect-[3/4] relative">
          <AppImage
            src={product.image}
            alt={product.alt}
            fill
            className="object-cover product-card-img"
            sizes="(max-width: 640px) 50vw, 25vw" />
          
          <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-colors duration-500" />

          {/* Badge */}
          {product.badge &&
          <div className="absolute top-3 left-3">
              <span className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full ${
            product.badge === 'Bestseller' ? 'bg-white text-black' :
            product.badge === 'New' ? 'bg-white text-black' : 'glass-panel text-white'}`
            }>
                {product.badge}
              </span>
            </div>
          }

          {/* Stock indicator */}
          {!product.inStock &&
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <span className="text-xs font-semibold uppercase tracking-widest text-white/70 glass-panel px-3 py-1.5 rounded-full">
                Out of Stock
              </span>
            </div>
          }

          {/* Wishlist */}
          <button
            onClick={() => setWishlisted(!wishlisted)}
            className="absolute top-3 right-3 w-8 h-8 rounded-full glass-panel flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 hover-lift"
            aria-label="Add to wishlist">
            
            <Icon
              name={wishlisted ? 'HeartIcon' : 'HeartIcon'}
              variant={wishlisted ? 'solid' : 'outline'}
              size={14}
              className={wishlisted ? 'text-white' : 'text-white/70'} />
            
          </button>

          {/* Quick add */}
          {product.inStock &&
          <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0">
              <Link href="/product-details" className="w-full btn-primary text-xs py-2.5 rounded-xl flex items-center justify-center gap-1.5">
                <Icon name="ShoppingBagIcon" size={14} />
                Quick View
              </Link>
            </div>
          }
        </div>
      </div>

      {/* Info */}
      <div className="px-1">
        <div className="flex items-start justify-between gap-2 mb-1.5">
          <div>
            <p className="text-[10px] text-white/35 uppercase tracking-widest mb-0.5">{product.category}</p>
            <Link href="/product-details" className="text-sm font-semibold text-white hover:text-white/70 transition-colors tracking-tight leading-snug">
              {product.name}
            </Link>
          </div>
          <div className="text-right flex-shrink-0">
            <div className="text-sm font-bold font-mono-custom text-white">£E{product.price}</div>
            {product.originalPrice &&
            <div className="text-xs font-mono-custom text-white/30 line-through">£E{product.originalPrice}</div>
            }
          </div>
        </div>

        {/* Stock availability */}
        <div className="flex items-center gap-1.5 mb-2">
          <div className={`w-1.5 h-1.5 rounded-full ${product.stock === 0 ? 'bg-white/20' : product.stock <= 3 ? 'bg-amber-400/80' : 'bg-white/60'}`} />
          <span className={`text-[10px] font-medium ${stockColor}`}>{stockLabel}</span>
        </div>

        {/* Rating */}
        <div className="flex items-center gap-1.5 mb-2.5">
          <div className="flex gap-0.5">
            {[...Array(5)].map((_, i) =>
            <Icon
              key={i}
              name="StarIcon"
              variant={i < Math.floor(product.rating) ? 'solid' : 'outline'}
              size={11}
              className={i < Math.floor(product.rating) ? 'star-filled' : 'star-empty'} />
            )}
          </div>
          <span className="text-[10px] text-white/35 font-mono-custom">{product.rating} ({product.reviews})</span>
        </div>

        {/* Size selector */}
        {product.sizes.length > 1 && (
          <div className="flex gap-1 flex-wrap mb-2">
            {product.sizes.map((size, si) =>
            <button
              key={size}
              onClick={() => setSelectedSize(si)}
              className={`px-2 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide transition-all duration-200 ${
              selectedSize === si ?
              'bg-white text-black' : 'border border-white/15 text-white/40 hover:border-white/40 hover:text-white/70'}`
              }>
              {size}
            </button>
            )}
          </div>
        )}

        {/* Variant selector */}
        <div className="flex gap-1.5 flex-wrap">
          {product.variants.map((variant, vi) =>
          <button
            key={variant}
            onClick={() => setSelectedVariant(vi)}
            className={`px-2 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide transition-all duration-200 ${
            selectedVariant === vi ?
            'bg-white text-black' : 'border border-white/15 text-white/40 hover:border-white/40 hover:text-white/70'}`
            }>
            
              {variant}
            </button>
          )}
        </div>
      </div>
    </div>);

};

const BestsellersSection: React.FC<BestsellersSectionProps> = ({ selectedCategory = 'all', onCategoryChange }) => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll('.scroll-reveal');
            elements.forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 100);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const filteredProducts = selectedCategory === 'all' ?
  products :
  products.filter((p) => p.categoryId === selectedCategory);

  const activeLabel = categoryTabs.find((t) => t.id === selectedCategory)?.label ?? 'All Products';

  return (
    <section id="products" ref={sectionRef} className="py-20 md:py-28 px-5 md:px-8 bg-primary">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-5 mb-8 scroll-reveal">
          <div>
            <span className="section-label block mb-3">Top Picks</span>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-white">
              {selectedCategory === 'all' ? 'All Products' : activeLabel}
            </h2>
          </div>
          <div className="text-sm text-white/40 font-mono-custom">
            {filteredProducts.length} item{filteredProducts.length !== 1 ? 's' : ''}
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-2 mb-10 overflow-x-auto pb-2 scroll-reveal">
          {categoryTabs.map((tab) =>
          <button
            key={tab.id}
            onClick={() => onCategoryChange?.(tab.id)}
            className={`flex-shrink-0 px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-widest transition-all duration-200 ${
            selectedCategory === tab.id ?
            'bg-white text-black' : 'border border-white/15 text-white/50 hover:border-white/40 hover:text-white/80'}`
            }>
              {tab.label}
            </button>
          )}
        </div>

        {/* Grid */}
        {filteredProducts.length > 0 ?
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {filteredProducts.map((product, i) =>
          <ProductCard key={product.id} product={product} index={i} />
          )}
          </div> :

        <div className="flex flex-col items-center justify-center py-20 text-center">
            <Icon name="ShoppingBagIcon" size={40} className="text-white/20 mb-4" />
            <p className="text-white/40 text-sm uppercase tracking-widest">No products in this category yet</p>
          </div>
        }
      </div>
    </section>);

};

export default BestsellersSection;