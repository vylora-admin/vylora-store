'use client';

import React, { useEffect, useRef } from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

interface Testimonial {
  id: string;
  name: string;
  city: string;
  rating: number;
  text: string;
  product: string;
  avatar: string;
  alt: string;
}

const testimonials: Testimonial[] = [
{
  id: 't1',
  name: 'Nour El-Sayed',
  city: 'Cairo',
  rating: 5,
  text: 'The Cairo Layered Chain is absolutely stunning. Got it delivered in 3 days to Heliopolis. The quality is way better than what I expected for the price — feels like something from a high-end boutique.',
  product: 'Cairo Layered Chain',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1a26b85ef-1772100323023.png",
  alt: 'Young Egyptian woman smiling, warm natural light'
},
{
  id: 't2',
  name: 'Karim Hassan',
  city: 'Alexandria',
  rating: 5,
  text: 'Bought the Pharaoh Cuff as a gift for my sister. She loved it. Packaging was premium and delivery was faster than expected. JewelHub is now my go-to for accessories.',
  product: 'Pharaoh Cuff Bracelet',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_15239ed16-1772496552091.png",
  alt: 'Young Egyptian man, professional portrait'
},
{
  id: 't3',
  name: 'Yasmine Mahmoud',
  city: 'Giza',
  rating: 5,
  text: 'I was skeptical about buying jewelry online but the return policy convinced me. The Nile Solitaire Ring fits perfectly and the silver finish hasn\'t tarnished after 2 months of daily wear.',
  product: 'Nile Solitaire Ring',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_12bb5c3c2-1763300828468.png",
  alt: 'Egyptian woman with dark hair, bright background portrait'
}];


const TestimonialsSection: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll('.scroll-reveal');
            elements.forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 120);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 md:py-28 px-5 md:px-8 bg-secondary">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12 scroll-reveal">
          <span className="section-label block mb-3">What Customers Say</span>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-white mb-4">
            Loved Across Egypt
          </h2>
          <div className="flex items-center justify-center gap-2">
            <div className="flex gap-0.5">
              {[...Array(5)].map((_, i) =>
              <Icon key={i} name="StarIcon" variant="solid" size={16} className="star-filled" />
              )}
            </div>
            <span className="text-sm font-mono-custom text-white/50">4.9 · 1,200+ reviews</span>
          </div>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {testimonials.map((t, i) =>
          <div
            key={t.id}
            className={`glass-panel-hover p-6 rounded-xl2 scroll-reveal stagger-${i + 1}`}>
            
              {/* Stars */}
              <div className="flex gap-0.5 mb-4">
                {[...Array(5)].map((_, si) =>
              <Icon
                key={si}
                name="StarIcon"
                variant={si < t.rating ? 'solid' : 'outline'}
                size={13}
                className={si < t.rating ? 'star-filled' : 'star-empty'} />

              )}
              </div>

              {/* Quote icon */}
              <Icon name="ChatBubbleLeftRightIcon" size={20} className="text-white/15 mb-3" />

              {/* Text */}
              <p className="text-sm text-white/60 font-light leading-relaxed mb-5 italic">
                &ldquo;{t.text}&rdquo;
              </p>

              {/* Product tag */}
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white/5 rounded-full mb-4">
                <Icon name="TagIcon" size={10} className="text-white/30" />
                <span className="text-[10px] text-white/40 font-medium">{t.product}</span>
              </div>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-white/8">
                <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0">
                  <AppImage
                  src={t.avatar}
                  alt={t.alt}
                  width={36}
                  height={36}
                  className="object-cover w-full h-full grayscale" />
                
                </div>
                <div>
                  <p className="text-sm font-semibold text-white tracking-tight">{t.name}</p>
                  <p className="text-[11px] text-white/35 flex items-center gap-1">
                    <Icon name="MapPinIcon" size={10} className="text-white/25" />
                    {t.city}, Egypt
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>);

};

export default TestimonialsSection;