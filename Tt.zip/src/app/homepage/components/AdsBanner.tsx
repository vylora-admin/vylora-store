'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

const ads = [
  {
    id: 1,
    tag: 'Limited Offer',
    headline: 'Up to 30% OFF on All Chains',
    sub: 'This week only — shop the Cairo Layered Chain and Nile Delicate Chain at exclusive prices.',
    cta: 'Shop Chains',
    href: '/homepage#products',
    bg: 'from-white/8 to-white/3',
    accent: 'text-white',
  },
  {
    id: 2,
    tag: 'New Arrivals',
    headline: 'Luxor Ring Collection Is Here',
    sub: 'Discover the new Luxor Stacking Ring Set — handcrafted, limited edition, ships in 24 hours.',
    cta: 'View Rings',
    href: '/product-details',
    bg: 'from-white/10 to-white/2',
    accent: 'text-white',
  },
  {
    id: 3,
    tag: 'Free Shipping',
    headline: 'Free Delivery on Orders Over £E500',
    sub: 'Shop across all categories and enjoy free shipping to Cairo, Giza, Alexandria, and 27+ cities.',
    cta: 'Start Shopping',
    href: '/homepage#products',
    bg: 'from-white/6 to-white/2',
    accent: 'text-white',
  },
];

const AdsBanner: React.FC = () => {
  const [activeAd, setActiveAd] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveAd((prev) => (prev + 1) % ads.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const ad = ads[activeAd];

  return (
    <section className="py-10 px-5 md:px-8 bg-primary">
      <div className="max-w-7xl mx-auto">
        {/* Main rotating ad */}
        <div className={`relative rounded-2xl bg-gradient-to-r ${ad.bg} border border-white/10 overflow-hidden`}>
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(255,255,255,0.05),transparent_60%)]" />
          <div className="relative px-8 py-10 md:py-12 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex-1">
              <span className="inline-block px-3 py-1 rounded-full border border-white/20 text-[10px] font-bold uppercase tracking-widest text-white/60 mb-4">
                {ad.tag}
              </span>
              <h2 className="font-display font-bold text-2xl md:text-3xl text-white mb-3 leading-tight">{ad.headline}</h2>
              <p className="text-white/50 text-sm leading-relaxed max-w-lg">{ad.sub}</p>
            </div>
            <div className="flex-shrink-0">
              <Link href={ad.href} className="btn-primary whitespace-nowrap">
                {ad.cta}
                <Icon name="ArrowRightIcon" size={16} />
              </Link>
            </div>
          </div>
          {/* Dots */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5">
            {ads.map((_, i) => (
              <button
                key={i}
                onClick={() => setActiveAd(i)}
                className={`h-1 rounded-full transition-all duration-300 ${i === activeAd ? 'w-6 bg-white' : 'w-1.5 bg-white/25'}`}
                aria-label={`Go to ad ${i + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Static mini-ads grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4">
          {[
            { icon: 'SparklesIcon', title: 'New Season Drops', sub: 'Fresh designs every week', href: '/homepage#products' },
            { icon: 'GiftIcon', title: 'Gift Wrapping', sub: 'Free on orders over £E800', href: '/checkout' },
            { icon: 'TagIcon', title: 'Loyalty Rewards', sub: 'Earn points on every order', href: '/dashboard' },
          ].map((item) => (
            <Link
              key={item.title}
              href={item.href}
              className="glass-panel rounded-xl p-5 flex items-center gap-4 hover:border-white/20 transition-all duration-300 group"
            >
              <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center flex-shrink-0 group-hover:bg-white/10 transition-colors">
                <Icon name={item.icon as any} size={18} className="text-white/60" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">{item.title}</p>
                <p className="text-xs text-white/35 mt-0.5">{item.sub}</p>
              </div>
              <Icon name="ChevronRightIcon" size={14} className="text-white/20 ml-auto group-hover:text-white/50 transition-colors" />
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AdsBanner;