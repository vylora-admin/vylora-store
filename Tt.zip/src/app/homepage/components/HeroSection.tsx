'use client';

import React, { useEffect, useRef } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

const HeroSection: React.FC = () => {
  const headlineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (headlineRef.current) {
        const lines = headlineRef.current.querySelectorAll('.line-reveal');
        lines.forEach((line, i) => {
          setTimeout(() => {
            line.classList.add('revealed');
          }, i * 180);
        });
      }
    }, 200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="relative min-h-screen flex flex-col justify-end pb-16 md:pb-24 overflow-hidden">
      
      {/* Background */}
      <div className="absolute inset-0 -z-10">
        <AppImage
          src="https://img.rocket.new/generatedImages/rocket_gen_img_1379d2420-1765462845749.png"
          alt="Luxury jewelry"
          fill
          priority
          className="object-cover object-center"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/50 to-black/20" />
        <div className="absolute inset-0 bg-black/25" />
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto w-full px-5 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end">

          {/* Headline */}
          <div className="lg:col-span-8" ref={headlineRef}>


            <div className="mt-20 md:mt-0 mb-4 opacity-0 animate-fade-in-up delay-100">
              <span className="text-xs md:text-sm uppercase tracking-[0.35em] text-white/80 font-medium">
                New Collection 2026
              </span>
            </div>

            <h1 className="text-[clamp(3rem,8vw,6.5rem)] font-bold leading-[1.05] tracking-tight">
              <span className="line-reveal block">
                <span className="text-white">Crafted for</span>
              </span>
              <span className="line-reveal block">
                <span className="text-white/90 italic font-light">Cairo.</span>
              </span>
              <span className="line-reveal block">
                <span className="text-white">Worn with</span>
              </span>
              <span className="line-reveal block">
                <span className="text-white/80">Intent.</span>
              </span>
            </h1>
          </div>

          {/* CTA */}
          <div className="lg:col-span-4 flex flex-col gap-5 opacity-0 animate-fade-in-up delay-500">
            <p className="text-base md:text-lg text-white/65 font-light leading-relaxed max-w-sm">
              Premium chains, rings, earrings, and hand accessories. Delivered across Egypt in 2–4 days.
            </p>

            <div className="flex flex-col sm:flex-row lg:flex-col gap-3">
              <Link href="/homepage#products" className="btn-primary">
                Shop Collections
                <Icon name="ArrowRightIcon" size={16} />
              </Link>
              <Link href="/track-order" className="btn-outline">
                Track My Order
              </Link>
            </div>

            <div className="flex items-center gap-5 pt-2">
              {[
                { icon: 'TruckIcon', label: 'Free shipping 500£E+' },
                { icon: 'ShieldCheckIcon', label: 'Secure checkout' },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-2">
                  <Icon name={item.icon as 'TruckIcon'} size={14} className="text-white/40" />
                  <span className="text-[11px] text-white/40 font-medium">{item.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mt-12 pt-8 border-t border-white/10">
          {[
            { value: '12K+', label: 'Happy Customers' },
            { value: '500+', label: 'Unique Designs' },
            { value: '27', label: 'Cities in Egypt' },
          ].map((stat, i) => (
            <div key={stat.label} className={`opacity-0 animate-fade-in-up delay-${(i + 4) * 100}`}>
              <div className="text-2xl md:text-3xl font-bold font-mono-custom text-white">{stat.value}</div>
              <div className="text-[11px] text-white/40 uppercase tracking-[0.15em] mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 opacity-40">
        <span className="text-[10px] uppercase tracking-ultra text-white/50">Scroll</span>
        <div className="w-px h-8 bg-gradient-to-b from-white/50 to-transparent" />
      </div>
    </section>
  );
};

export default HeroSection;