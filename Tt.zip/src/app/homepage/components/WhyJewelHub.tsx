'use client';

import React, { useEffect, useRef } from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

const features = [
{
  icon: 'SparklesIcon',
  title: 'Certified Materials',
  description: '925 sterling silver, 18K gold-plated, and stainless steel — every piece tested for quality before listing.'
},
{
  icon: 'TruckIcon',
  title: 'Egypt-Wide Delivery',
  description: 'Fast shipping to Cairo, Alexandria, Giza, Mansoura, and 23+ more cities in 2–4 business days.'
},
{
  icon: 'ArrowPathIcon',
  title: '14-Day Easy Returns',
  description: 'Not satisfied? Return within 14 days, no questions asked. Full refund or exchange guaranteed.'
},
{
  icon: 'LockClosedIcon',
  title: 'Secure Payments',
  description: 'Pay with Visa, Mastercard, Fawry, or cash on delivery. Your data is always protected.'
}];


const WhyJewelHub: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll('.scroll-reveal');
            elements.forEach((el, i) => {
              setTimeout(() => el.classList.add('revealed'), i * 120);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" ref={sectionRef} className="py-20 md:py-28 px-5 md:px-8 bg-secondary">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image side */}
          <div className="relative scroll-reveal order-2 lg:order-1">
            <div className="relative h-[420px] md:h-[540px] rounded-xl3 overflow-hidden">
              <AppImage
                src="https://img.rocket.new/generatedImages/rocket_gen_img_16b2ef368-1772200148160.png"
                alt="Jewelry craftsperson working on delicate pieces, dark workshop atmosphere, focused beam lighting"
                fill
                className="object-cover img-grayscale"
                sizes="(max-width: 1024px) 100vw, 50vw" />
              
              <div className="absolute inset-0 bg-gradient-to-br from-black/40 to-transparent" />
            </div>

            {/* Floating stat card */}
            <div className="absolute -bottom-5 -right-3 md:-right-6 glass-panel p-5 rounded-2xl shadow-2xl animate-border-glow scroll-reveal stagger-2">
              <div className="text-3xl font-bold font-mono-custom text-white mb-1">12,400+</div>
              <div className="text-[11px] uppercase tracking-ultra text-white/40">Orders Delivered</div>
              <div className="flex gap-0.5 mt-2">
                {[...Array(5)].map((_, i) =>
                <Icon key={i} name="StarIcon" size={12} variant="solid" className="star-filled" />
                )}
              </div>
            </div>

            {/* Second floating card */}
            <div className="absolute top-6 -left-3 md:-left-6 glass-panel px-4 py-3 rounded-xl scroll-reveal stagger-3">
              <div className="text-xl font-bold font-mono-custom text-white">500+</div>
              <div className="text-[10px] uppercase tracking-ultra text-white/40">Unique Designs</div>
            </div>
          </div>

          {/* Content side */}
          <div className="order-1 lg:order-2 flex flex-col justify-between h-full">
            <div className="scroll-reveal">
              <span className="section-label block mb-4">Why Choose Us</span>
              <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight mb-5">
                Egypt&apos;s Most Trusted <br />
                <span className="text-white/50 italic font-light">Accessories Store.</span>
              </h2>
              <p className="text-base text-white/50 font-light leading-relaxed max-w-lg mb-10">
                From handpicked designs to doorstep delivery, we&apos;ve built JewelHub for Egyptians who want international quality without international prices.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {features.map((feature, i) =>
              <div
                key={feature.title}
                className={`glass-panel-hover p-5 rounded-xl2 scroll-reveal stagger-${i + 1}`}>
                
                  <div className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center mb-3">
                    <Icon name={feature.icon as 'SparklesIcon'} size={18} className="text-white/70" />
                  </div>
                  <h3 className="text-sm font-bold text-white mb-1.5 tracking-tight">{feature.title}</h3>
                  <p className="text-xs text-white/40 font-light leading-relaxed">{feature.description}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>);

};

export default WhyJewelHub;