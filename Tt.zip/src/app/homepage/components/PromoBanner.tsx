import React from 'react';
import Icon from '@/components/ui/AppIcon';

const PromoBanner: React.FC = () => {
  return (
    <div className="bg-white py-3 px-5">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-8 text-center">
        {[
          { icon: 'TruckIcon', text: 'Free Shipping on orders over £E500' },
          { icon: 'ArrowPathIcon', text: 'Easy 14-day returns' },
          { icon: 'StarIcon', text: 'Authentic premium materials' },
        ].map((item) => (
          <div key={item.text} className="flex items-center gap-2">
            <Icon name={item.icon as 'TruckIcon'} size={14} className="text-black/60" />
            <span className="text-xs font-semibold uppercase tracking-[0.15em] text-black/70">{item.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PromoBanner;