'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

const cartItems = [
{ name: 'Layered Gold Chain Necklace', variant: 'Gold · 45cm', price: 3200, qty: 1, img: "https://img.rocket.new/generatedImages/rocket_gen_img_1e2bdec37-1767341378914.png", alt: 'Layered gold chain necklace product thumbnail' },
{ name: 'Diamond Stud Earrings', variant: 'Gold · Standard', price: 4500, qty: 1, img: "https://img.rocket.new/generatedImages/rocket_gen_img_109595504-1772688429998.png", alt: 'Diamond stud earrings product thumbnail' }];


const steps = ['Cart', 'Shipping', 'Payment', 'Confirm'];

export default function CheckoutPage() {
  const [step, setStep] = useState(1);
  const [payMethod, setPayMethod] = useState('card');
  const [form, setForm] = useState({
    firstName: '', lastName: '', email: '', phone: '',
    address: '', city: '', governorate: '', postalCode: '',
    cardNumber: '', cardExpiry: '', cardCvv: '', cardName: ''
  });

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);
  const shipping = 0;
  const total = subtotal + shipping;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  return (
    <main className="bg-primary min-h-screen">
      <Header />
      <div className="pt-28 pb-20 px-5 md:px-8 max-w-6xl mx-auto">
        {/* Steps */}
        <div className="flex items-center justify-center gap-0 mb-12">
          {steps.map((s, i) =>
          <React.Fragment key={s}>
              <div className="flex flex-col items-center gap-1.5">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all duration-300 ${
              i < step ? 'bg-white border-white text-black' :
              i === step ? 'bg-transparent border-white text-white' : 'bg-transparent border-white/15 text-white/25'}`
              }>
                  {i < step ? <Icon name="CheckIcon" size={14} /> : i + 1}
                </div>
                <span className={`text-[10px] font-semibold uppercase tracking-wider hidden sm:block ${i <= step ? 'text-white/60' : 'text-white/20'}`}>{s}</span>
              </div>
              {i < steps.length - 1 &&
            <div className={`h-px w-12 sm:w-20 mx-2 transition-all duration-300 ${i < step ? 'bg-white/40' : 'bg-white/10'}`} />
            }
            </React.Fragment>
          )}
        </div>

        <div className="grid lg:grid-cols-5 gap-10">
          {/* Form Side */}
          <div className="lg:col-span-3">
            {step === 1 &&
            <div>
                <h2 className="font-display font-bold text-2xl text-white mb-6">Your Cart</h2>
                <div className="space-y-4 mb-8">
                  {cartItems.map((item) =>
                <div key={item.name} className="glass-panel rounded-xl p-4 flex items-center gap-4">
                      <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                        <img src={item.img} alt={item.alt} className="w-full h-full object-cover grayscale" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-white truncate">{item.name}</p>
                        <p className="text-xs text-white/40 mt-0.5">{item.variant}</p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="text-sm font-semibold text-white price-tag">EGP {item.price.toLocaleString()}</p>
                        <p className="text-xs text-white/30 mt-0.5">Qty: {item.qty}</p>
                      </div>
                    </div>
                )}
                </div>
                <button onClick={() => setStep(2)} className="btn-primary w-full">
                  Continue to Shipping
                  <Icon name="ArrowRightIcon" size={16} />
                </button>
              </div>
            }

            {step === 2 &&
            <div>
                <h2 className="font-display font-bold text-2xl text-white mb-6">Shipping Details</h2>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">First Name</label>
                    <input name="firstName" value={form.firstName} onChange={handleChange} placeholder="Sara" className="input-field" />
                  </div>
                  <div>
                    <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">Last Name</label>
                    <input name="lastName" value={form.lastName} onChange={handleChange} placeholder="Ahmed" className="input-field" />
                  </div>
                </div>
                <div className="mb-4">
                  <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">Email Address</label>
                  <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="sara@email.com" className="input-field" />
                </div>
                <div className="mb-4">
                  <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">Phone Number</label>
                  <input name="phone" value={form.phone} onChange={handleChange} placeholder="+20 100 000 0000" className="input-field" />
                </div>
                <div className="mb-4">
                  <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">Street Address</label>
                  <input name="address" value={form.address} onChange={handleChange} placeholder="15 Tahrir Square, Apt 4B" className="input-field" />
                </div>
                <div className="grid grid-cols-3 gap-4 mb-8">
                  <div className="col-span-2">
                    <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">City</label>
                    <input name="city" value={form.city} onChange={handleChange} placeholder="Cairo" className="input-field" />
                  </div>
                  <div>
                    <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">Postal Code</label>
                    <input name="postalCode" value={form.postalCode} onChange={handleChange} placeholder="11511" className="input-field" />
                  </div>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setStep(1)} className="btn-outline flex-1">Back</button>
                  <button onClick={() => setStep(3)} className="btn-primary flex-1">
                    Continue to Payment
                    <Icon name="ArrowRightIcon" size={16} />
                  </button>
                </div>
              </div>
            }

            {step === 3 &&
            <div>
                <h2 className="font-display font-bold text-2xl text-white mb-6">Payment Method</h2>
                <div className="space-y-3 mb-6">
                  {[
                { id: 'card', label: 'Credit / Debit Card', icon: 'CreditCardIcon' },
                { id: 'vodafone', label: 'Vodafone Cash', icon: 'DevicePhoneMobileIcon' },
                { id: 'instapay', label: 'InstaPay', icon: 'BoltIcon' },
                { id: 'cod', label: 'Cash on Delivery', icon: 'BanknotesIcon' }].
                map((method) =>
                <button
                  key={method.id}
                  onClick={() => setPayMethod(method.id)}
                  className={`w-full flex items-center gap-4 p-4 rounded-xl border transition-all duration-300 ${
                  payMethod === method.id ? 'border-white bg-white/5' : 'border-white/10 hover:border-white/25'}`
                  }>
                  
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${payMethod === method.id ? 'border-white' : 'border-white/20'}`}>
                        {payMethod === method.id && <div className="w-2.5 h-2.5 rounded-full bg-white" />}
                      </div>
                      <Icon name={method.icon as any} size={18} className="text-white/50" />
                      <span className="text-sm font-semibold text-white">{method.label}</span>
                    </button>
                )}
                </div>

                {payMethod === 'card' &&
              <div className="glass-panel rounded-xl p-5 space-y-4 mb-6">
                    <div>
                      <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">Card Number</label>
                      <input name="cardNumber" value={form.cardNumber} onChange={handleChange} placeholder="1234 5678 9012 3456" className="input-field font-mono" maxLength={19} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">Expiry Date</label>
                        <input name="cardExpiry" value={form.cardExpiry} onChange={handleChange} placeholder="MM / YY" className="input-field font-mono" maxLength={7} />
                      </div>
                      <div>
                        <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">CVV</label>
                        <input name="cardCvv" value={form.cardCvv} onChange={handleChange} placeholder="•••" className="input-field font-mono" maxLength={4} type="password" />
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">Cardholder Name</label>
                      <input name="cardName" value={form.cardName} onChange={handleChange} placeholder="SARA AHMED" className="input-field uppercase" />
                    </div>
                  </div>
              }

                {payMethod === 'vodafone' &&
              <div className="glass-panel rounded-xl p-5 mb-6">
                    <div className="flex items-center gap-3 mb-3">
                      <Icon name="DevicePhoneMobileIcon" size={20} className="text-white/60" />
                      <p className="text-sm font-semibold text-white">Vodafone Cash Payment</p>
                    </div>
                    <p className="text-xs text-white/40 mb-4">You will be redirected to complete your Vodafone Cash payment securely.</p>
                    <Link href="/vodafone-cash" className="btn-outline w-full text-sm justify-center">
                      Continue to Vodafone Cash
                      <Icon name="ArrowRightIcon" size={14} />
                    </Link>
                  </div>
              }

                {payMethod === 'instapay' &&
              <div className="glass-panel rounded-xl p-5 mb-6">
                    <div className="flex items-center gap-3 mb-3">
                      <Icon name="BoltIcon" size={20} className="text-white/60" />
                      <p className="text-sm font-semibold text-white">InstaPay Payment</p>
                    </div>
                    <p className="text-xs text-white/40 mb-4">Pay instantly using your bank&apos;s InstaPay service. Fast, secure, CBE regulated.</p>
                    <Link href="/instapay" className="btn-outline w-full text-sm justify-center">
                      Continue to InstaPay
                      <Icon name="ArrowRightIcon" size={14} />
                    </Link>
                  </div>
              }

                {payMethod === 'cod' &&
              <div className="glass-panel rounded-xl p-5 mb-6">
                    <div className="flex items-center gap-3 mb-3">
                      <Icon name="BanknotesIcon" size={20} className="text-white/60" />
                      <p className="text-sm font-semibold text-white">Cash on Delivery</p>
                    </div>
                    <p className="text-xs text-white/40">Pay in cash when your order arrives. Available across Egypt.</p>
                  </div>
              }

                <div className="flex gap-3">
                  <button onClick={() => setStep(2)} className="btn-outline flex-1">Back</button>
                  <button
                    onClick={() => {
                      if (payMethod === 'vodafone') {
                        window.location.href = '/vodafone-cash';
                      } else if (payMethod === 'instapay') {
                        window.location.href = '/instapay';
                      } else {
                        setStep(4);
                      }
                    }}
                    className="btn-primary flex-1">
                    Place Order
                    <Icon name="LockClosedIcon" size={16} />
                  </button>
                </div>
              </div>
            }

            {step === 4 &&
            <div className="text-center py-10">
                <div className="w-20 h-20 rounded-full bg-white/5 border border-white/20 flex items-center justify-center mx-auto mb-6">
                  <Icon name="CheckIcon" size={36} className="text-white" />
                </div>
                <h2 className="font-display font-bold text-3xl text-white mb-3">Order Confirmed!</h2>
                <p className="text-white/50 mb-2">Your order has been placed successfully.</p>
                <p className="font-mono text-white/40 text-sm mb-8">Order ID: #JH-2026-0042</p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Link href="/order-confirmation" className="btn-primary">View Order Details</Link>
                  <Link href="/track-order" className="btn-outline">Track Your Order</Link>
                </div>
              </div>
            }
          </div>

          {/* Order Summary */}
          {step < 4 &&
          <div className="lg:col-span-2">
              <div className="glass-panel rounded-2xl p-6 sticky top-28">
                <h3 className="font-display font-semibold text-white mb-5">Order Summary</h3>
                <div className="space-y-3 mb-5">
                  {cartItems.map((item) =>
                <div key={item.name} className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 relative">
                        <img src={item.img} alt={item.alt} className="w-full h-full object-cover grayscale" />
                        <span className="absolute -top-1 -right-1 w-4 h-4 bg-white text-black text-[9px] font-bold rounded-full flex items-center justify-center">{item.qty}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-white truncate">{item.name}</p>
                        <p className="text-[10px] text-white/30">{item.variant}</p>
                      </div>
                      <p className="text-xs font-semibold text-white price-tag flex-shrink-0">EGP {item.price.toLocaleString()}</p>
                    </div>
                )}
                </div>
                <div className="border-t border-white/8 pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-white/40">Subtotal</span>
                    <span className="text-white price-tag">EGP {subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/40">Shipping</span>
                    <span className="text-white">{shipping === 0 ? 'Free' : `EGP ${shipping}`}</span>
                  </div>
                  <div className="flex justify-between text-base font-bold pt-2 border-t border-white/8">
                    <span className="text-white">Total</span>
                    <span className="text-white price-tag">EGP {total.toLocaleString()}</span>
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-2 text-xs text-white/30">
                  <Icon name="LockClosedIcon" size={12} />
                  <span>Secure checkout · SSL encrypted</span>
                </div>
              </div>
            </div>
          }
        </div>
      </div>
      <Footer />
    </main>);

}