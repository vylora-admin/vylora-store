'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

const images = [
{ src: "https://img.rocket.new/generatedImages/rocket_gen_img_1e2bdec37-1767341378914.png", alt: 'Layered gold chain necklace front view on white background' },
{ src: "https://images.unsplash.com/photo-1708221382764-299d9e3ad257", alt: 'Gold chain necklace detail close up showing clasp' },
{ src: "https://images.unsplash.com/photo-1730339023436-edfb94f4b98b", alt: 'Gold chain necklace worn on neck side view' },
{ src: "https://img.rocket.new/generatedImages/rocket_gen_img_10f1a9d99-1773292468148.png", alt: 'Gold chain necklace flat lay on dark surface' }];


const reviews = [
{ name: 'Nour M.', rating: 5, date: 'March 2026', comment: 'Absolutely stunning piece. The quality exceeded my expectations — it arrived beautifully packaged and the gold finish is perfect.' },
{ name: 'Layla K.', rating: 5, date: 'February 2026', comment: 'Bought this as a gift for my sister. She loved it! The chain is delicate but feels very sturdy. Will definitely order again.' },
{ name: 'Hana S.', rating: 4, date: 'January 2026', comment: 'Beautiful necklace, very elegant. Shipping was fast and the packaging was luxurious. Slightly shorter than expected but still gorgeous.' }];


const relatedProducts = [
{ name: 'Diamond Pendant', price: 'EGP 4,200', img: "https://images.unsplash.com/photo-1651641242443-39ba46428ff7", alt: 'Diamond pendant necklace on white background' },
{ name: 'Pearl Choker', price: 'EGP 1,950', img: "https://img.rocket.new/generatedImages/rocket_gen_img_14a1828f8-1768141549532.png", alt: 'Pearl choker necklace close up' },
{ name: 'Gold Hoop Earrings', price: 'EGP 1,100', img: "https://images.unsplash.com/photo-1708222169126-08b9102ccc0d", alt: 'Gold hoop earrings pair on white surface' },
{ name: 'Silver Chain Set', price: 'EGP 2,800', img: "https://images.unsplash.com/photo-1609767965255-132f5982efd4", alt: 'Silver chain necklace set layered' }];


export default function ProductDetailsPage() {
  const [activeImg, setActiveImg] = useState(0);
  const [selectedMetal, setSelectedMetal] = useState('Gold');
  const [selectedLength, setSelectedLength] = useState('45cm');
  const [qty, setQty] = useState(1);
  const [wishlisted, setWishlisted] = useState(false);

  return (
    <main className="bg-primary min-h-screen">
      <Header />
      <div className="pt-28 pb-20 px-5 md:px-8 max-w-7xl mx-auto">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-xs text-white/30 mb-8">
          <Link href="/homepage" className="hover:text-white transition-colors">Home</Link>
          <Icon name="ChevronRightIcon" size={12} className="text-white/20" />
          <Link href="/homepage#collections" className="hover:text-white transition-colors">Collections</Link>
          <Icon name="ChevronRightIcon" size={12} className="text-white/20" />
          <span className="text-white/60">Layered Gold Chain</span>
        </nav>

        <div className="grid lg:grid-cols-2 gap-12 xl:gap-20">
          {/* Image Gallery */}
          <div className="flex flex-col-reverse md:flex-row gap-4">
            {/* Thumbnails */}
            <div className="flex md:flex-col gap-3 overflow-x-auto md:overflow-visible">
              {images.map((img, i) =>
              <button
                key={i}
                onClick={() => setActiveImg(i)}
                className={`flex-shrink-0 w-16 h-16 md:w-20 md:h-20 rounded-xl overflow-hidden border-2 transition-all duration-300 ${
                activeImg === i ? 'border-white' : 'border-white/10 hover:border-white/30'}`
                }>
                
                  <img src={img.src} alt={img.alt} className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-300" />
                </button>
              )}
            </div>
            {/* Main Image */}
            <div className="flex-1 aspect-square rounded-2xl overflow-hidden relative group">
              <img
                src={images[activeImg].src}
                alt={images[activeImg].alt}
                className="w-full h-full object-cover transition-all duration-700 group-hover:scale-105" />
              
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <button className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/60 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Icon name="MagnifyingGlassPlusIcon" size={16} className="text-white" />
              </button>
            </div>
          </div>

          {/* Product Info */}
          <div className="flex flex-col">
            <div className="flex items-start justify-between gap-4 mb-2">
              <p className="section-label">Chains Collection</p>
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) =>
                <Icon key={i} name="StarIcon" size={14} className="star-filled" />
                )}
                <span className="text-xs text-white/40 ml-1">(47 reviews)</span>
              </div>
            </div>

            <h1 className="font-display font-bold text-3xl md:text-4xl text-white tracking-tight mb-4">
              Layered Gold Chain Necklace
            </h1>

            <div className="flex items-baseline gap-3 mb-6">
              <span className="font-display font-bold text-3xl text-white price-tag">EGP 3,200</span>
              <span className="text-white/30 line-through text-lg price-tag">EGP 4,000</span>
              <span className="text-xs font-semibold text-white bg-white/10 px-2 py-1 rounded-full">20% OFF</span>
            </div>

            {/* Stock Status */}
            <div className="flex items-center gap-2 mb-6">
              <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
              <span className="text-xs text-white/60">In Stock — Only 4 left</span>
            </div>

            <p className="text-white/50 text-sm leading-relaxed mb-8">
              A timeless layered chain crafted from 18K gold-plated sterling silver. Designed for the modern Egyptian woman — effortlessly elegant, built to last. Each piece is handcrafted and quality-checked before shipping.
            </p>

            {/* Metal Selector */}
            <div className="mb-6">
              <p className="text-xs font-semibold uppercase tracking-widest text-white/40 mb-3">Metal: <span className="text-white">{selectedMetal}</span></p>
              <div className="flex gap-2">
                {['Gold', 'Silver', 'Rose Gold'].map((metal) =>
                <button
                  key={metal}
                  onClick={() => setSelectedMetal(metal)}
                  className={`px-4 py-2 rounded-full text-xs font-semibold border transition-all duration-300 ${
                  selectedMetal === metal ?
                  'bg-white text-black border-white' : 'bg-transparent text-white/50 border-white/15 hover:border-white/40'}`
                  }>
                  
                    {metal}
                  </button>
                )}
              </div>
            </div>

            {/* Length Selector */}
            <div className="mb-8">
              <p className="text-xs font-semibold uppercase tracking-widest text-white/40 mb-3">Length: <span className="text-white">{selectedLength}</span></p>
              <div className="flex gap-2">
                {['40cm', '45cm', '50cm', '55cm'].map((len) =>
                <button
                  key={len}
                  onClick={() => setSelectedLength(len)}
                  className={`w-14 h-10 rounded-lg text-xs font-semibold border transition-all duration-300 ${
                  selectedLength === len ?
                  'bg-white text-black border-white' : 'bg-transparent text-white/50 border-white/15 hover:border-white/40'}`
                  }>
                  
                    {len}
                  </button>
                )}
              </div>
            </div>

            {/* Quantity + Actions */}
            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center gap-0 border border-white/15 rounded-full overflow-hidden">
                <button onClick={() => setQty(Math.max(1, qty - 1))} className="w-10 h-10 flex items-center justify-center text-white/60 hover:text-white hover:bg-white/5 transition-colors">
                  <Icon name="MinusIcon" size={14} />
                </button>
                <span className="w-10 text-center text-sm font-semibold text-white font-mono">{qty}</span>
                <button onClick={() => setQty(qty + 1)} className="w-10 h-10 flex items-center justify-center text-white/60 hover:text-white hover:bg-white/5 transition-colors">
                  <Icon name="PlusIcon" size={14} />
                </button>
              </div>
              <Link href="/checkout" className="btn-primary flex-1 text-sm">
                <Icon name="ShoppingBagIcon" size={16} />
                Add to Cart
              </Link>
              <button
                onClick={() => setWishlisted(!wishlisted)}
                className={`w-11 h-11 rounded-full border flex items-center justify-center transition-all duration-300 ${
                wishlisted ? 'bg-white border-white' : 'border-white/15 hover:border-white/40'}`
                }>
                
                <Icon name="HeartIcon" size={18} className={wishlisted ? 'text-black' : 'text-white/50'} />
              </button>
            </div>

            <Link href="/checkout" className="btn-outline w-full text-sm mb-8">
              Buy Now
            </Link>

            {/* Features */}
            <div className="grid grid-cols-3 gap-3 pt-6 border-t border-white/8">
              {[
              { icon: 'TruckIcon', label: 'Free Delivery', sub: 'Cairo & Giza' },
              { icon: 'ArrowPathIcon', label: '14-Day Returns', sub: 'Easy returns' },
              { icon: 'ShieldCheckIcon', label: 'Authentic', sub: '18K certified' }].
              map((f) =>
              <div key={f.label} className="text-center">
                  <Icon name={f.icon as any} size={18} className="text-white/30 mx-auto mb-1.5" />
                  <p className="text-xs font-semibold text-white/60">{f.label}</p>
                  <p className="text-[10px] text-white/30">{f.sub}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="mt-20">
          <div className="flex items-center justify-between mb-8">
            <div>
              <p className="section-label mb-2">Customer Reviews</p>
              <h2 className="font-display font-bold text-2xl text-white">What they say</h2>
            </div>
            <div className="text-right">
              <p className="font-display font-bold text-4xl text-white">4.8</p>
              <div className="flex items-center gap-1 justify-end mt-1">
                {[...Array(5)].map((_, i) => <Icon key={i} name="StarIcon" size={12} className="star-filled" />)}
              </div>
              <p className="text-xs text-white/30 mt-1">47 reviews</p>
            </div>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {reviews.map((review) =>
            <div key={review.name} className="glass-panel rounded-2xl p-6">
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(review.rating)].map((_, i) => <Icon key={i} name="StarIcon" size={12} className="star-filled" />)}
                </div>
                <p className="text-sm text-white/70 leading-relaxed mb-4">&ldquo;{review.comment}&rdquo;</p>
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-white">{review.name}</p>
                  <p className="text-xs text-white/30">{review.date}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Related Products */}
        <div className="mt-20">
          <p className="section-label mb-2">You May Also Like</p>
          <h2 className="font-display font-bold text-2xl text-white mb-8">Related Products</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {relatedProducts.map((product) =>
            <Link href="/product-details" key={product.name} className="glass-panel rounded-xl overflow-hidden group product-card">
                <div className="aspect-square overflow-hidden">
                  <img src={product.img} alt={product.alt} className="w-full h-full object-cover product-card-img grayscale group-hover:grayscale-0 transition-all duration-500" />
                </div>
                <div className="p-4">
                  <p className="text-sm font-semibold text-white">{product.name}</p>
                  <p className="text-xs text-white/40 price-tag mt-1">{product.price}</p>
                </div>
              </Link>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </main>);

}