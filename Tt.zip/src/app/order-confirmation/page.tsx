'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

const orderItems = [
{ name: 'Cairo Layered Chain', variant: 'Gold · 45cm', price: 850, qty: 1, img: "https://img.rocket.new/generatedImages/rocket_gen_img_1e2bdec37-1767341378914.png", alt: 'Layered gold chain necklace' },
{ name: 'Nile Solitaire Ring', variant: 'Silver · Size 7', price: 620, qty: 2, img: "https://img.rocket.new/generatedImages/rocket_gen_img_151872816-1764835752209.png", alt: 'Minimalist silver ring' }];


export default function OrderConfirmationPage() {
  const [orderId, setOrderId] = useState('');

  useEffect(() => {
    setOrderId(`JH-2026-${Math.floor(Math.random() * 9000 + 1000)}`);
  }, []);

  const subtotal = orderItems?.reduce((sum, item) => sum + item?.price * item?.qty, 0);
  const shipping = 0;
  const total = subtotal + shipping;

  return (
    <main className="bg-primary min-h-screen">
      <Header />
      <div className="pt-28 pb-20 px-5 md:px-8 max-w-3xl mx-auto">
        {/* Success Header */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 rounded-full bg-white/5 border-2 border-white/30 flex items-center justify-center mx-auto mb-6 animate-pulse">
            <Icon name="CheckIcon" size={36} className="text-white" />
          </div>
          <h1 className="font-display font-bold text-4xl text-white mb-3">Order Confirmed!</h1>
          <p className="text-white/50 text-base mb-2">Thank you for your purchase. Your order has been placed successfully.</p>
          <p className="font-mono text-white/40 text-sm">Order ID: <span className="text-white font-semibold">#{orderId}</span></p>
        </div>

        {/* Order Status Timeline */}
        <div className="glass-panel rounded-2xl p-6 mb-6">
          <h2 className="font-display font-semibold text-white mb-5">Order Status</h2>
          <div className="relative">
            {[
            { label: 'Order Placed', sub: 'Your order has been received', done: true },
            { label: 'Processing', sub: 'We are preparing your items', done: true },
            { label: 'Shipped', sub: 'Your order is on its way', done: false },
            { label: 'Delivered', sub: 'Estimated 2–4 business days', done: false }]?.
            map((step, i, arr) =>
            <div key={step?.label} className="flex items-start gap-4 mb-5 last:mb-0">
                <div className="flex flex-col items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 flex-shrink-0 ${step?.done ? 'bg-white border-white' : 'bg-transparent border-white/20'}`}>
                    {step?.done ?
                  <Icon name="CheckIcon" size={14} className="text-black" /> :

                  <span className="w-2 h-2 rounded-full bg-white/20" />
                  }
                  </div>
                  {i < arr?.length - 1 &&
                <div className={`w-px h-8 mt-1 ${step?.done ? 'bg-white/30' : 'bg-white/10'}`} />
                }
                </div>
                <div className="pt-1">
                  <p className={`text-sm font-semibold ${step?.done ? 'text-white' : 'text-white/30'}`}>{step?.label}</p>
                  <p className={`text-xs mt-0.5 ${step?.done ? 'text-white/50' : 'text-white/20'}`}>{step?.sub}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Order Items */}
        <div className="glass-panel rounded-2xl p-6 mb-6">
          <h2 className="font-display font-semibold text-white mb-5">Order Items</h2>
          <div className="space-y-4">
            {orderItems?.map((item) =>
            <div key={item?.name} className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0">
                  <img src={item?.img} alt={item?.alt} className="w-full h-full object-cover grayscale" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-white truncate">{item?.name}</p>
                  <p className="text-xs text-white/40 mt-0.5">{item?.variant}</p>
                  <p className="text-xs text-white/30 mt-0.5">Qty: {item?.qty}</p>
                </div>
                <p className="text-sm font-semibold text-white font-mono flex-shrink-0">EGP {(item?.price * item?.qty)?.toLocaleString()}</p>
              </div>
            )}
          </div>
          <div className="border-t border-white/8 mt-5 pt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-white/40">Subtotal</span>
              <span className="text-white font-mono">EGP {subtotal?.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-white/40">Shipping</span>
              <span className="text-white">Free</span>
            </div>
            <div className="flex justify-between text-base font-bold pt-2 border-t border-white/8">
              <span className="text-white">Total Paid</span>
              <span className="text-white font-mono">EGP {total?.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Shipping Info */}
        <div className="glass-panel rounded-2xl p-6 mb-8">
          <h2 className="font-display font-semibold text-white mb-4">Shipping Details</h2>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-xs text-white/30 uppercase tracking-widest mb-1">Name</p>
              <p className="text-white">Sara Ahmed</p>
            </div>
            <div>
              <p className="text-xs text-white/30 uppercase tracking-widest mb-1">Phone</p>
              <p className="text-white">+20 100 000 0000</p>
            </div>
            <div className="col-span-2">
              <p className="text-xs text-white/30 uppercase tracking-widest mb-1">Address</p>
              <p className="text-white">15 Tahrir Square, Apt 4B, Cairo, 11511</p>
            </div>
            <div>
              <p className="text-xs text-white/30 uppercase tracking-widest mb-1">Payment</p>
              <p className="text-white">Vodafone Cash</p>
            </div>
            <div>
              <p className="text-xs text-white/30 uppercase tracking-widest mb-1">Estimated Delivery</p>
              <p className="text-white">2–4 Business Days</p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Link href="/track-order" className="btn-primary flex-1 justify-center">
            <Icon name="MapPinIcon" size={16} />
            Track Your Order
          </Link>
          <Link href="/homepage" className="btn-outline flex-1 justify-center">
            <Icon name="ShoppingBagIcon" size={16} />
            Continue Shopping
          </Link>
        </div>

        <p className="text-center text-xs text-white/25 mt-6">
          A confirmation email has been sent to your registered email address.
        </p>
      </div>
      <Footer />
    </main>);

}