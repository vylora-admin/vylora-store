import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const sections = [
  {
    title: '1. Acceptance of Terms',
    content: `By accessing and using JewelHub ("the Platform"), you agree to be bound by these Terms and Conditions. If you do not agree to these terms, please do not use our services. JewelHub reserves the right to update these terms at any time, and continued use of the platform constitutes acceptance of any changes.`,
  },
  {
    title: '2. Products & Availability',
    content: `All jewelry products listed on JewelHub are subject to availability. We operate exclusively within Egypt and ship to all Egyptian governorates. Product images are for illustrative purposes; actual items may vary slightly due to the handcrafted nature of our jewelry. We reserve the right to discontinue any product at any time.`,
  },
  {
    title: '3. Pricing & Payment',
    content: `All prices are listed in Egyptian Pounds (EGP) and include applicable taxes. JewelHub accepts credit/debit cards, cash on delivery, and InstaPay. Prices may change without prior notice. In the event of a pricing error, we reserve the right to cancel orders placed at incorrect prices and will notify you promptly.`,
  },
  {
    title: '4. Orders & Cancellations',
    content: `Orders are confirmed via email upon successful placement. You may cancel an order within 2 hours of placement by contacting our support team. Once an order has been shipped, cancellations are not accepted. Custom or personalized orders cannot be cancelled after production begins.`,
  },
  {
    title: '5. Shipping & Delivery',
    content: `JewelHub offers delivery across all Egyptian governorates. Standard delivery takes 2–5 business days for Cairo and Giza, and 5–10 business days for other governorates. Free shipping is available on orders above EGP 1,500. Delivery times are estimates and may vary due to courier delays or unforeseen circumstances.`,
  },
  {
    title: '6. Returns & Exchanges',
    content: `We accept returns within 14 days of delivery for unused, unworn items in original packaging. Items showing signs of wear, damage, or alteration are not eligible for return. To initiate a return, contact our support team with your order ID and reason for return. Refunds are processed within 7–14 business days after we receive the returned item.`,
  },
  {
    title: '7. Intellectual Property',
    content: `All content on JewelHub — including product images, descriptions, logos, and design elements — is the exclusive property of JewelHub and protected by Egyptian and international copyright laws. Unauthorized reproduction, distribution, or use of any content is strictly prohibited.`,
  },
  {
    title: '8. Limitation of Liability',
    content: `JewelHub shall not be liable for any indirect, incidental, or consequential damages arising from the use of our platform or products. Our total liability in any matter related to these terms shall not exceed the amount paid for the specific order in question.`,
  },
  {
    title: '9. Governing Law',
    content: `These Terms and Conditions are governed by the laws of the Arab Republic of Egypt. Any disputes arising from these terms shall be subject to the exclusive jurisdiction of Egyptian courts.`,
  },
  {
    title: '10. Contact Us',
    content: `For questions about these Terms and Conditions, please contact us at: legal@jewelhub.eg or call +20 100 000 0000. Our customer service team is available Sunday through Thursday, 9:00 AM – 6:00 PM (Cairo time).`,
  },
];

export default function TermsPage() {
  return (
    <main className="bg-primary min-h-screen">
      <Header />
      <div className="pt-28 pb-20 px-5 md:px-8 max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <p className="section-label mb-3">Legal</p>
          <h1 className="font-display font-bold text-4xl md:text-5xl text-white tracking-tight mb-4">
            Terms & Conditions
          </h1>
          <p className="text-white/40 text-sm">Last updated: April 12, 2026</p>
        </div>

        {/* Intro */}
        <div className="glass-panel rounded-2xl p-6 mb-8">
          <p className="text-white/60 text-sm leading-relaxed">
            Welcome to JewelHub. These Terms and Conditions govern your use of our online jewelry store and the purchase of products through our platform. Please read these terms carefully before making a purchase. By using JewelHub, you confirm that you are at least 18 years of age and have the legal capacity to enter into these terms.
          </p>
        </div>

        {/* Sections */}
        <div className="space-y-6">
          {sections?.map((section) => (
            <div key={section?.title} className="border-b border-white/8 pb-6 last:border-0">
              <h2 className="font-display font-semibold text-white text-lg mb-3">{section?.title}</h2>
              <p className="text-white/50 text-sm leading-relaxed">{section?.content}</p>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </main>
  );
}