'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

interface WishlistItem {
  id: string;
  name: string;
  category: string;
  price: string;
  originalPrice?: string;
  inStock: boolean;
  image: string;
  alt: string;
}

const initialWishlist: WishlistItem[] = [
{
  id: '1',
  name: 'Gold Chain Necklace 18K',
  category: 'Chains',
  price: 'EGP 2,450',
  originalPrice: 'EGP 2,900',
  inStock: true,
  image: "https://images.unsplash.com/photo-1689775703516-03f680c49018",
  alt: 'Elegant 18K gold chain necklace with delicate links on white background'
},
{
  id: '2',
  name: 'Diamond Solitaire Ring',
  category: 'Rings',
  price: 'EGP 5,800',
  inStock: true,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_188eb08c6-1765769440426.png",
  alt: 'Classic diamond solitaire engagement ring with brilliant cut stone'
},
{
  id: '3',
  name: 'Pearl Drop Earrings',
  category: 'Earrings',
  price: 'EGP 1,200',
  inStock: false,
  image: "https://images.unsplash.com/photo-1704637397679-f37e5e0dc429",
  alt: 'Elegant pearl drop earrings with gold setting on dark background'
},
{
  id: '4',
  name: 'Rose Gold Bangle',
  category: 'Bracelets',
  price: 'EGP 3,100',
  inStock: true,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1bf3a659b-1766833690334.png",
  alt: 'Sleek rose gold bangle bracelet with polished finish'
}];


export default function WishlistPage() {
  const [items, setItems] = useState<WishlistItem[]>(initialWishlist);

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  return (
    <main className="bg-primary min-h-screen">
      <Header />
      <div className="pt-28 pb-20 px-5 md:px-8 max-w-6xl mx-auto">
        {/* Page Header */}
        <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <p className="section-label mb-3">My Account</p>
            <h1 className="font-display font-bold text-4xl md:text-5xl text-white tracking-tight">
              Wishlist
            </h1>
            <p className="text-white/40 text-sm mt-2">{items.length} saved item{items.length !== 1 ? 's' : ''}</p>
          </div>
          {items.length > 0 &&
          <Link href="/checkout" className="btn-primary text-xs px-6 py-3 flex items-center gap-2 self-start md:self-auto">
              <Icon name="ShoppingBagIcon" size={16} className="text-black" />
              Add All to Cart
            </Link>
          }
        </div>

        {items.length === 0 ?
        <div className="glass-panel rounded-2xl p-16 text-center">
            <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-6">
              <Icon name="HeartIcon" size={28} className="text-white/20" />
            </div>
            <h2 className="font-display font-semibold text-xl text-white mb-2">Your wishlist is empty</h2>
            <p className="text-white/40 text-sm mb-8">Save your favourite pieces to find them easily later.</p>
            <Link href="/homepage" className="btn-primary text-xs px-8 py-3">
              Explore Collections
            </Link>
          </div> :

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {items.map((item) =>
          <div key={item.id} className="glass-panel rounded-2xl overflow-hidden group">
                {/* Image */}
                <div className="relative aspect-square bg-white/3 overflow-hidden">
                  <img
                src={item.image}
                alt={item.alt}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
              
                  {!item.inStock &&
              <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                      <span className="text-white/60 text-xs font-semibold uppercase tracking-widest">Out of Stock</span>
                    </div>
              }
                  <button
                onClick={() => removeItem(item.id)}
                className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/60 backdrop-blur-sm border border-white/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white/10"
                aria-label="Remove from wishlist">
                
                    <Icon name="XMarkIcon" size={14} className="text-white" />
                  </button>
                </div>

                {/* Info */}
                <div className="p-4">
                  <p className="text-white/30 text-xs uppercase tracking-widest mb-1">{item.category}</p>
                  <h3 className="font-display font-semibold text-sm text-white mb-2 leading-snug">{item.name}</h3>
                  <div className="flex items-center gap-2 mb-4">
                    <span className="font-mono text-sm text-white">{item.price}</span>
                    {item.originalPrice &&
                <span className="font-mono text-xs text-white/30 line-through">{item.originalPrice}</span>
                }
                  </div>
                  <div className="flex gap-2">
                    <button
                  disabled={!item.inStock}
                  className={`flex-1 text-xs py-2.5 rounded-xl font-semibold transition-all duration-200 ${
                  item.inStock ?
                  'bg-white text-black hover:bg-white/90' : 'bg-white/5 text-white/20 cursor-not-allowed border border-white/10'}`
                  }>
                  
                      {item.inStock ? 'Add to Cart' : 'Notify Me'}
                    </button>
                    <button
                  onClick={() => removeItem(item.id)}
                  className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
                  aria-label="Remove item">
                  
                      <Icon name="TrashIcon" size={14} className="text-white/40" />
                    </button>
                  </div>
                </div>
              </div>
          )}
          </div>
        }

        {/* Continue Shopping */}
        {items.length > 0 &&
        <div className="mt-10 text-center">
            <Link href="/homepage" className="btn-outline text-xs px-8 py-3">
              Continue Shopping
            </Link>
          </div>
        }
      </div>
      <Footer />
    </main>);

}