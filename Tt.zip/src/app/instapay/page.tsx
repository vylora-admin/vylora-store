'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

export default function InstapayPage() {
  const [ipaAddress, setIpaAddress] = useState('');
  const [step, setStep] = useState<'form' | 'confirm' | 'success'>('form');
  const [loading, setLoading] = useState(false);

  const orderTotal = 1470;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('confirm');
  };

  const handleConfirm = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep('success');
    }, 2000);
  };

  return (
    <main className="bg-primary min-h-screen">
      <Header />
      <div className="pt-28 pb-20 px-5 md:px-8 max-w-lg mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/15 flex items-center justify-center mx-auto mb-4">
            <Icon name="BoltIcon" size={28} className="text-white" />
          </div>
          <h1 className="font-display font-bold text-3xl text-white mb-2">InstaPay</h1>
          <p className="text-white/40 text-sm">Fast & secure payment via InstaPay IPA address</p>
        </div>

        {step === 'form' && (
          <div>
            {/* Order Summary */}
            <div className="glass-panel rounded-2xl p-5 mb-6">
              <div className="flex justify-between items-center">
                <span className="text-sm text-white/50">Order Total</span>
                <span className="font-display font-bold text-xl text-white font-mono">EGP {orderTotal.toLocaleString()}</span>
              </div>
            </div>

            {/* JewelHub IPA */}
            <div className="glass-panel rounded-2xl p-5 mb-6 border border-white/15">
              <p className="text-xs text-white/30 uppercase tracking-widest mb-2">JewelHub IPA Address</p>
              <div className="flex items-center justify-between gap-3">
                <p className="font-mono text-lg font-bold text-white tracking-wide">jewelhub@instapay</p>
                <button
                  onClick={() => navigator.clipboard?.writeText('jewelhub@instapay')}
                  className="flex items-center gap-1.5 text-xs text-white/40 hover:text-white transition-colors border border-white/10 hover:border-white/30 px-3 py-1.5 rounded-lg"
                >
                  <Icon name="ClipboardDocumentIcon" size={12} />
                  Copy
                </button>
              </div>
              <p className="text-xs text-white/25 mt-2">Send payment to this IPA address from your banking app</p>
            </div>

            {/* Instructions */}
            <div className="glass-panel rounded-2xl p-5 mb-6">
              <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <Icon name="InformationCircleIcon" size={16} className="text-white/50" />
                How to Pay via InstaPay
              </h3>
              <ol className="space-y-3">
                {[
                  'Open your bank app (CIB, NBE, Banque Misr, etc.)',
                  'Go to InstaPay and select "Send Money"',
                  `Enter JewelHub IPA: jewelhub@instapay`,
                  `Enter amount: EGP ${orderTotal.toLocaleString()}`,
                  'Enter your IPA address below and submit to confirm',
                ].map((s, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-white/60">
                    <span className="w-5 h-5 rounded-full bg-white/10 text-white text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">{i + 1}</span>
                    {s}
                  </li>
                ))}
              </ol>
            </div>

            {/* Supported Banks */}
            <div className="glass-panel rounded-2xl p-5 mb-6">
              <p className="text-xs text-white/30 uppercase tracking-widest mb-3">Supported Banks</p>
              <div className="flex flex-wrap gap-2">
                {['CIB', 'NBE', 'Banque Misr', 'QNB', 'HSBC Egypt', 'Alex Bank', 'Faisal Bank', 'Arab African'].map((bank) => (
                  <span key={bank} className="px-3 py-1 rounded-full border border-white/10 text-xs text-white/40">{bank}</span>
                ))}
              </div>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">Your IPA Address</label>
                <input
                  type="text"
                  value={ipaAddress}
                  onChange={(e) => setIpaAddress(e.target.value)}
                  placeholder="yourname@instapay"
                  className="input-field font-mono"
                  required
                />
                <p className="text-xs text-white/25 mt-2">We will verify your payment using this address</p>
              </div>

              <button type="submit" className="btn-primary w-full">
                <Icon name="LockClosedIcon" size={16} />
                Confirm Payment — EGP {orderTotal.toLocaleString()}
              </button>
            </form>

            <div className="flex items-center justify-center gap-2 mt-4 text-xs text-white/25">
              <Icon name="ShieldCheckIcon" size={12} />
              <span>Secured by InstaPay · CBE regulated</span>
            </div>

            <div className="mt-6 text-center">
              <Link href="/checkout" className="text-xs text-white/30 hover:text-white/60 transition-colors underline underline-offset-2">
                ← Back to Checkout
              </Link>
            </div>
          </div>
        )}

        {step === 'confirm' && (
          <div className="glass-panel rounded-2xl p-8 text-center">
            <div className="w-14 h-14 rounded-full bg-white/5 border border-white/20 flex items-center justify-center mx-auto mb-5">
              <Icon name="BoltIcon" size={24} className="text-white" />
            </div>
            <h2 className="font-display font-bold text-2xl text-white mb-3">Confirm Payment</h2>
            <p className="text-white/50 text-sm mb-2">Verifying payment from:</p>
            <p className="font-mono text-white font-bold text-lg mb-1">{ipaAddress}</p>
            <p className="font-mono text-white/40 text-sm mb-2">To: jewelhub@instapay</p>
            <p className="font-mono text-white/40 text-sm mb-8">Amount: EGP {orderTotal.toLocaleString()}</p>
            <div className="flex flex-col gap-3">
              <button onClick={handleConfirm} disabled={loading} className="btn-primary w-full">
                {loading ? (
                  <>
                    <Icon name="ArrowPathIcon" size={16} className="animate-spin" />
                    Verifying Payment...
                  </>
                ) : (
                  <>
                    <Icon name="CheckIcon" size={16} />
                    Confirm Payment
                  </>
                )}
              </button>
              <button onClick={() => setStep('form')} className="btn-outline w-full">Edit Details</button>
            </div>
          </div>
        )}

        {step === 'success' && (
          <div className="text-center">
            <div className="w-20 h-20 rounded-full bg-white/5 border-2 border-white/30 flex items-center justify-center mx-auto mb-6">
              <Icon name="CheckIcon" size={36} className="text-white" />
            </div>
            <h2 className="font-display font-bold text-3xl text-white mb-3">Payment Confirmed!</h2>
            <p className="text-white/50 mb-2">Your InstaPay payment has been verified.</p>
            <p className="text-white/30 text-sm mb-8">Your order is now being processed and will be shipped shortly.</p>
            <div className="flex flex-col gap-3">
              <Link href="/order-confirmation" className="btn-primary justify-center">
                <Icon name="CheckCircleIcon" size={16} />
                View Order Confirmation
              </Link>
              <Link href="/track-order" className="btn-outline justify-center">
                Track My Order
              </Link>
            </div>
          </div>
        )}
      </div>
      <Footer />
    </main>
  );
}
