'use client';

import React, { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

interface TrackingStep {
  label: string;
  description: string;
  date: string;
  done: boolean;
  active: boolean;
}

const mockTracking: TrackingStep[] = [
{ label: 'Order Placed', description: 'Your order has been received and confirmed.', date: 'Apr 10, 2026 · 10:32 AM', done: true, active: false },
{ label: 'Processing', description: 'Your jewelry is being carefully prepared and quality-checked.', date: 'Apr 10, 2026 · 2:15 PM', done: true, active: false },
{ label: 'Shipped', description: 'Your order is on its way with Aramex Express.', date: 'Apr 11, 2026 · 9:00 AM', done: true, active: true },
{ label: 'Out for Delivery', description: 'Your package is with the delivery courier.', date: 'Expected Apr 12, 2026', done: false, active: false },
{ label: 'Delivered', description: 'Package delivered to your address.', date: 'Expected Apr 12, 2026', done: false, active: false }];


export default function TrackOrderPage() {
  const [orderId, setOrderId] = useState('');
  const [email, setEmail] = useState('');
  const [tracked, setTracked] = useState(false);

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (orderId.trim()) setTracked(true);
  };

  return (
    <main className="bg-primary min-h-screen">
      <Header />
      <div className="pt-28 pb-20 px-5 md:px-8 max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <p className="section-label mb-3">Order Tracking</p>
          <h1 className="font-display font-bold text-4xl md:text-5xl text-white tracking-tight mb-4">
            Track Your Order
          </h1>
          <p className="text-white/40 text-sm max-w-md mx-auto">
            Enter your order ID and email address to get real-time updates on your jewelry delivery.
          </p>
        </div>

        {/* Search Form */}
        <div className="glass-panel rounded-2xl p-6 md:p-8 mb-10">
          <form onSubmit={handleTrack} className="space-y-5">
            <div>
              <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-2">Order ID</label>
              <input
                value={orderId}
                onChange={(e) => setOrderId(e.target.value)}
                placeholder="#JH-2026-001"
                className="input-field font-mono"
                required />
              
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-widest text-white/40 block mb-2">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="sara@email.com"
                className="input-field" />
              
            </div>
            <button type="submit" className="btn-primary w-full">
              <Icon name="MagnifyingGlassIcon" size={16} />
              Track Order
            </button>
          </form>
        </div>

        {/* Tracking Result */}
        {tracked &&
        <div className="animate-fade-in-up">
            {/* Order Info */}
            <div className="glass-panel rounded-2xl p-6 mb-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="font-mono text-white font-semibold">#JH-2026-001</p>
                  <p className="text-xs text-white/40 mt-1">Placed on Apr 10, 2026</p>
                </div>
                <span className="text-xs font-semibold uppercase tracking-wider px-3 py-1.5 rounded-full border text-white bg-white/10 border-white/20">
                  Shipped
                </span>
              </div>
              <div className="flex items-center gap-3 pt-4 border-t border-white/8">
                <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                  <img
                  src="https://img.rocket.new/generatedImages/rocket_gen_img_1e2bdec37-1767341378914.png"
                  alt="Layered gold chain necklace order item thumbnail"
                  className="w-full h-full object-cover grayscale" />
                
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">Layered Gold Chain Necklace</p>
                  <p className="text-xs text-white/40">Gold · 45cm · Qty 1</p>
                </div>
                <p className="text-sm font-semibold text-white price-tag ml-auto">EGP 3,200</p>
              </div>
            </div>

            {/* Courier Info */}
            <div className="glass-panel rounded-xl p-4 mb-6 flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
                <Icon name="TruckIcon" size={18} className="text-white/50" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-white">Aramex Express</p>
                <p className="text-xs text-white/40 font-mono mt-0.5">Tracking: ARX-2026-88421</p>
              </div>
              <p className="text-xs text-white/40">Est. Apr 12</p>
            </div>

            {/* Timeline */}
            <div className="glass-panel rounded-2xl p-6 md:p-8">
              <h3 className="font-display font-semibold text-white mb-6">Delivery Timeline</h3>
              <div className="relative">
                {/* Vertical line */}
                <div className="absolute left-4 top-4 bottom-4 w-px bg-white/8" />

                <div className="space-y-0">
                  {mockTracking.map((step, i) =>
                <div key={step.label} className="flex gap-5 pb-8 last:pb-0 relative">
                      {/* Dot */}
                      <div className={`relative z-10 w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center border-2 transition-all ${
                  step.done ?
                  'bg-white border-white' :
                  step.active ?
                  'bg-transparent border-white animate-pulse' : 'bg-transparent border-white/15'}`
                  }>
                        {step.done ?
                    <Icon name="CheckIcon" size={14} className="text-black" /> :

                    <div className={`w-2 h-2 rounded-full ${step.active ? 'bg-white' : 'bg-white/20'}`} />
                    }
                      </div>

                      {/* Content */}
                      <div className={`flex-1 pt-1 ${!step.done && !step.active ? 'opacity-40' : ''}`}>
                        <div className="flex items-center justify-between gap-4 mb-1">
                          <p className={`text-sm font-semibold ${step.active ? 'text-white' : step.done ? 'text-white' : 'text-white/50'}`}>
                            {step.label}
                            {step.active && <span className="ml-2 text-[10px] font-semibold uppercase tracking-wider bg-white/10 text-white/60 px-2 py-0.5 rounded-full">Current</span>}
                          </p>
                          <p className="text-[10px] text-white/30 font-mono flex-shrink-0">{step.date}</p>
                        </div>
                        <p className="text-xs text-white/40 leading-relaxed">{step.description}</p>
                      </div>
                    </div>
                )}
                </div>
              </div>
            </div>

            {/* Help */}
            <div className="mt-6 text-center">
              <p className="text-xs text-white/30">
                Need help with your order?{' '}
                <a href="mailto:support@jewelhub.eg" className="text-white/60 hover:text-white transition-colors underline underline-offset-2">
                  Contact Support
                </a>
              </p>
            </div>
          </div>
        }
      </div>
      <Footer />
    </main>);

}