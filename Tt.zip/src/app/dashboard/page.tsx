'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

interface Order {
  id: string;
  date: string;
  items: string;
  total: string;
  status: 'Delivered' | 'Shipped' | 'Processing' | 'Cancelled';
}

const orders: Order[] = [
{ id: '#JH-2024-001', date: 'Jan 15, 2026', items: 'Gold Chain Necklace × 1', total: 'EGP 2,450', status: 'Delivered' },
{ id: '#JH-2024-002', date: 'Feb 3, 2026', items: 'Diamond Ring × 1, Pearl Earrings × 1', total: 'EGP 5,800', status: 'Shipped' },
{ id: '#JH-2024-003', date: 'Mar 20, 2026', items: 'Silver Bracelet × 2', total: 'EGP 1,200', status: 'Processing' },
{ id: '#JH-2024-004', date: 'Apr 1, 2026', items: 'Rose Gold Earrings × 1', total: 'EGP 980', status: 'Delivered' }];


const statusColors: Record<Order['status'], string> = {
  Delivered: 'text-white bg-white/10 border-white/20',
  Shipped: 'text-white/80 bg-white/5 border-white/15',
  Processing: 'text-white/60 bg-white/5 border-white/10',
  Cancelled: 'text-white/30 bg-white/5 border-white/10'
};

const tabs = ['Overview', 'Orders', 'Wishlist', 'Addresses'];

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState('Overview');

  return (
    <main className="bg-primary min-h-screen">
      <Header />
      <div className="pt-28 pb-20 px-5 md:px-8 max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="mb-10">
          <p className="section-label mb-3">My Account</p>
          <h1 className="font-display font-bold text-4xl md:text-5xl text-white tracking-tight">Dashboard</h1>
        </div>

        {/* Profile Card */}
        <div className="glass-panel rounded-2xl p-6 md:p-8 mb-8 flex flex-col md:flex-row items-start md:items-center gap-6">
          <div className="w-16 h-16 rounded-full bg-white/10 border border-white/20 flex items-center justify-center flex-shrink-0">
            <Icon name="UserIcon" size={28} className="text-white/60" />
          </div>
          <div className="flex-1">
            <h2 className="font-display font-semibold text-xl text-white">Sara Ahmed</h2>
            <p className="text-white/40 text-sm mt-0.5">sara.ahmed@email.com · Cairo, Egypt</p>
            <p className="text-white/30 text-xs font-mono mt-1">Member since January 2025</p>
          </div>
          <Link href="/settings" className="btn-outline text-xs px-5 py-2.5">
            Edit Profile
          </Link>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {[
          { label: 'Total Orders', value: '12', icon: 'ShoppingBagIcon' },
          { label: 'Delivered', value: '9', icon: 'CheckCircleIcon' },
          { label: 'Total Spent', value: 'EGP 18,430', icon: 'CreditCardIcon' },
          { label: 'Wishlist', value: '5 items', icon: 'HeartIcon' }].
          map((stat) =>
          <div key={stat.label} className="glass-panel rounded-xl p-5">
              <Icon name={stat.icon as any} size={20} className="text-white/30 mb-3" />
              <p className="font-display font-bold text-2xl text-white price-tag">{stat.value}</p>
              <p className="text-white/40 text-xs mt-1">{stat.label}</p>
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-8 border-b border-white/8">
          {tabs.map((tab) =>
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-5 py-3 text-sm font-semibold transition-all duration-300 border-b-2 -mb-px ${
            activeTab === tab ?
            'text-white border-white' : 'text-white/30 border-transparent hover:text-white/60'}`
            }>
            
              {tab}
            </button>
          )}
        </div>

        {/* Tab Content */}
        {activeTab === 'Overview' &&
        <div className="grid md:grid-cols-2 gap-6">
            {/* Recent Orders */}
            <div className="glass-panel rounded-2xl p-6">
              <h3 className="font-display font-semibold text-white mb-4">Recent Orders</h3>
              <div className="space-y-3">
                {orders.slice(0, 3).map((order) =>
              <div key={order.id} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
                    <div>
                      <p className="text-sm font-semibold text-white font-mono">{order.id}</p>
                      <p className="text-xs text-white/40 mt-0.5">{order.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-white price-tag">{order.total}</p>
                      <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full border ${statusColors[order.status]}`}>
                        {order.status}
                      </span>
                    </div>
                  </div>
              )}
              </div>
              <Link href="#" onClick={() => setActiveTab('Orders')} className="text-xs text-white/40 hover:text-white transition-colors mt-4 inline-block">
                View all orders →
              </Link>
            </div>

            {/* Quick Actions */}
            <div className="glass-panel rounded-2xl p-6">
              <h3 className="font-display font-semibold text-white mb-4">Quick Actions</h3>
              <div className="space-y-2">
                {[
              { label: 'Track an Order', href: '/track-order', icon: 'TruckIcon' },
              { label: 'Browse Collections', href: '/homepage#collections', icon: 'SparklesIcon' },
              { label: 'Account Settings', href: '/settings', icon: 'Cog6ToothIcon' },
              { label: 'Privacy & Security', href: '/privacy', icon: 'ShieldCheckIcon' }].
              map((action) =>
              <Link
                key={action.label}
                href={action.href}
                className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors group">
                
                    <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center group-hover:border-white/20 transition-colors">
                      <Icon name={action.icon as any} size={16} className="text-white/50" />
                    </div>
                    <span className="text-sm text-white/60 group-hover:text-white transition-colors">{action.label}</span>
                    <Icon name="ArrowRightIcon" size={14} className="text-white/20 ml-auto group-hover:text-white/40 transition-colors" />
                  </Link>
              )}
              </div>
            </div>
          </div>
        }

        {activeTab === 'Orders' &&
        <div className="glass-panel rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/8">
                    <th className="text-left px-6 py-4 text-xs font-semibold uppercase tracking-widest text-white/30">Order</th>
                    <th className="text-left px-6 py-4 text-xs font-semibold uppercase tracking-widest text-white/30">Date</th>
                    <th className="text-left px-6 py-4 text-xs font-semibold uppercase tracking-widest text-white/30 hidden md:table-cell">Items</th>
                    <th className="text-left px-6 py-4 text-xs font-semibold uppercase tracking-widest text-white/30">Total</th>
                    <th className="text-left px-6 py-4 text-xs font-semibold uppercase tracking-widest text-white/30">Status</th>
                    <th className="px-6 py-4"></th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order, i) =>
                <tr key={order.id} className={`border-b border-white/5 last:border-0 hover:bg-white/2 transition-colors ${i % 2 === 0 ? '' : 'bg-white/1'}`}>
                      <td className="px-6 py-4 font-mono text-sm text-white">{order.id}</td>
                      <td className="px-6 py-4 text-sm text-white/50">{order.date}</td>
                      <td className="px-6 py-4 text-sm text-white/50 hidden md:table-cell">{order.items}</td>
                      <td className="px-6 py-4 text-sm font-semibold text-white price-tag">{order.total}</td>
                      <td className="px-6 py-4">
                        <span className={`text-[10px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-full border ${statusColors[order.status]}`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <Link href="/track-order" className="text-xs text-white/30 hover:text-white transition-colors">Track →</Link>
                      </td>
                    </tr>
                )}
                </tbody>
              </table>
            </div>
          </div>
        }

        {activeTab === 'Wishlist' &&
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
          { name: 'Layered Gold Chain', price: 'EGP 3,200', img: "https://img.rocket.new/generatedImages/rocket_gen_img_1e2bdec37-1767341378914.png", alt: 'Layered gold chain necklace on white background' },
          { name: 'Diamond Stud Earrings', price: 'EGP 4,500', img: "https://images.unsplash.com/photo-1655328723829-3140909b335b", alt: 'Diamond stud earrings close up' },
          { name: 'Silver Cuff Bracelet', price: 'EGP 1,800', img: "https://images.unsplash.com/photo-1681091637319-a47422751264", alt: 'Silver cuff bracelet on wrist' },
          { name: 'Rose Gold Ring', price: 'EGP 2,100', img: "https://images.unsplash.com/photo-1603561591411-07134e71a2a9", alt: 'Rose gold ring with gemstone' },
          { name: 'Pearl Drop Earrings', price: 'EGP 1,650', img: "https://img.rocket.new/generatedImages/rocket_gen_img_1c63115f2-1766743499462.png", alt: 'Pearl drop earrings hanging' }].
          map((item) =>
          <div key={item.name} className="glass-panel rounded-xl overflow-hidden group product-card">
                <div className="aspect-square overflow-hidden relative">
                  <img src={item.img} alt={item.alt} className="w-full h-full object-cover product-card-img grayscale group-hover:grayscale-0 transition-all duration-500" />
                  <button className="absolute top-3 right-3 w-7 h-7 rounded-full bg-black/60 flex items-center justify-center hover:bg-black transition-colors">
                    <Icon name="HeartIcon" size={14} className="text-white" />
                  </button>
                </div>
                <div className="p-4">
                  <p className="text-sm font-semibold text-white">{item.name}</p>
                  <p className="text-xs text-white/40 price-tag mt-1">{item.price}</p>
                  <Link href="/product-details" className="btn-primary text-xs px-4 py-2 mt-3 w-full">Add to Cart</Link>
                </div>
              </div>
          )}
          </div>
        }

        {activeTab === 'Addresses' &&
        <div className="grid md:grid-cols-2 gap-4">
            <div className="glass-panel rounded-2xl p-6 border border-white/20">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <span className="text-[10px] font-semibold uppercase tracking-widest text-white/40 bg-white/5 px-2 py-1 rounded-full">Default</span>
                  <h4 className="font-semibold text-white mt-2">Home Address</h4>
                </div>
                <button className="text-xs text-white/30 hover:text-white transition-colors">Edit</button>
              </div>
              <p className="text-sm text-white/60 leading-relaxed">Sara Ahmed<br />15 Tahrir Square, Apt 4B<br />Cairo, Egypt 11511<br />+20 100 123 4567</p>
            </div>
            <button className="glass-panel rounded-2xl p-6 border border-dashed border-white/10 hover:border-white/30 transition-colors flex flex-col items-center justify-center gap-3 group">
              <div className="w-10 h-10 rounded-full border border-white/10 group-hover:border-white/30 flex items-center justify-center transition-colors">
                <Icon name="PlusIcon" size={20} className="text-white/30 group-hover:text-white/60 transition-colors" />
              </div>
              <span className="text-sm text-white/30 group-hover:text-white/60 transition-colors">Add New Address</span>
            </button>
          </div>
        }
      </div>
      <Footer />
    </main>);

}