'use client';

import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

const OTP_LENGTH = 6;

export default function OtpVerificationPage() {
  const [otp, setOtp] = useState<string[]>(Array(OTP_LENGTH).fill(''));
  const [verified, setVerified] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resendTimer, setResendTimer] = useState(59);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (resendTimer > 0) {
      const t = setTimeout(() => setResendTimer((prev) => prev - 1), 1000);
      return () => clearTimeout(t);
    }
  }, [resendTimer]);

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    setError('');
    if (value && index < OTP_LENGTH - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, OTP_LENGTH);
    const newOtp = [...otp];
    pasted.split('').forEach((char, i) => { newOtp[i] = char; });
    setOtp(newOtp);
    inputRefs.current[Math.min(pasted.length, OTP_LENGTH - 1)]?.focus();
  };

  const handleVerify = () => {
    const code = otp.join('');
    if (code.length < OTP_LENGTH) {
      setError('Please enter the complete 6-digit code.');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setVerified(true);
    }, 1500);
  };

  const handleResend = () => {
    setResendTimer(59);
    setOtp(Array(OTP_LENGTH).fill(''));
    setError('');
    inputRefs.current[0]?.focus();
  };

  return (
    <main className="bg-primary min-h-screen flex flex-col">
      <Header />
      <div className="flex-1 flex items-center justify-center px-5 py-28">
        <div className="w-full max-w-md">
          <Link
            href="/forgot-password"
            className="inline-flex items-center gap-2 text-white/40 hover:text-white text-xs font-semibold uppercase tracking-widest transition-colors mb-10"
          >
            <Icon name="ArrowLeftIcon" size={14} />
            Back
          </Link>

          <div className="glass-panel rounded-3xl p-8 md:p-10">
            {!verified ? (
              <>
                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6">
                  <Icon name="DevicePhoneMobileIcon" size={24} className="text-white/60" />
                </div>

                <h1 className="font-display font-bold text-3xl text-white tracking-tight mb-2">
                  Verify Your Email
                </h1>
                <p className="text-white/40 text-sm mb-8 leading-relaxed">
                  Enter the 6-digit code we sent to your email address. The code expires in 10 minutes.
                </p>

                {/* OTP Inputs */}
                <div className="flex gap-3 justify-center mb-6" onPaste={handlePaste}>
                  {otp.map((digit, i) => (
                    <input
                      key={i}
                      ref={(el) => { inputRefs.current[i] = el; }}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleChange(i, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(i, e)}
                      className={`w-11 h-14 text-center text-xl font-bold font-mono rounded-xl border transition-all duration-200 bg-white/5 text-white focus:outline-none ${
                        digit
                          ? 'border-white/40 bg-white/10' :'border-white/10 focus:border-white/30'
                      } ${error ? 'border-red-400/50' : ''}`}
                    />
                  ))}
                </div>

                {error && (
                  <p className="text-center text-xs text-red-400 flex items-center justify-center gap-1.5 mb-4">
                    <Icon name="ExclamationCircleIcon" size={12} />
                    {error}
                  </p>
                )}

                <button
                  onClick={handleVerify}
                  disabled={loading || otp.join('').length < OTP_LENGTH}
                  className="btn-primary w-full py-3.5 text-sm flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed mb-4"
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    <>
                      Verify Code
                      <Icon name="ArrowRightIcon" size={16} className="text-black" />
                    </>
                  )}
                </button>

                {/* Resend */}
                <div className="text-center">
                  {resendTimer > 0 ? (
                    <p className="text-white/30 text-xs">
                      Resend code in{' '}
                      <span className="font-mono text-white/50">
                        0:{resendTimer.toString().padStart(2, '0')}
                      </span>
                    </p>
                  ) : (
                    <button
                      onClick={handleResend}
                      className="text-white text-xs font-semibold hover:text-white/70 transition-colors"
                    >
                      Resend Code
                    </button>
                  )}
                </div>
              </>
            ) : (
              <>
                <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center mb-6">
                  <Icon name="CheckCircleIcon" size={24} className="text-white" />
                </div>
                <h1 className="font-display font-bold text-3xl text-white tracking-tight mb-2">
                  Code Verified!
                </h1>
                <p className="text-white/40 text-sm mb-8 leading-relaxed">
                  Your identity has been confirmed. You can now set a new password for your account.
                </p>
                <Link
                  href="/change-password"
                  className="btn-primary w-full py-3.5 text-sm flex items-center justify-center gap-2"
                >
                  Set New Password
                  <Icon name="ArrowRightIcon" size={16} className="text-black" />
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
