'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Icon from '@/components/ui/AppIcon';

export default function VodafoneCashPage() {
  const [phone, setPhone] = useState('');
  const [step, setStep] = useState<'form' | 'confirm' | 'success'>('form');
  const [loading, setLoading] = useState(false);

  const orderTotal = 1470;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('confirm');
  };

  const handleConfirm = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep('success');
    }, 2000);
  };

  return (
    <main className="bg-primary min-h-screen">
      <Header />
      <div className="pt-28 pb-20 px-5 md:px-8 max-w-lg mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/15 flex items-center justify-center mx-auto mb-4">
            <Icon name="DevicePhoneMobileIcon" size={28} className="text-white" />
          </div>
          <h1 className="font-display font-bold text-3xl text-white mb-2">Vodafone Cash</h1>
          <p className="text-white/40 text-sm">Pay securely using your Vodafone Cash wallet</p>
        </div>

        {step === 'form' && (
          <div>
            {/* Order Summary */}
            <div className="glass-panel rounded-2xl p-5 mb-6">
              <div className="flex justify-between items-center">
                <span className="text-sm text-white/50">Order Total</span>
                <span className="font-display font-bold text-xl text-white font-mono">EGP {orderTotal.toLocaleString()}</span>
              </div>
            </div>

            {/* Instructions */}
            <div className="glass-panel rounded-2xl p-5 mb-6">
              <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <Icon name="InformationCircleIcon" size={16} className="text-white/50" />
                How to Pay
              </h3>
              <ol className="space-y-3">
                {[
                  'Enter your Vodafone Cash registered phone number below',
                  'You will receive a payment request on your phone',
                  'Open Vodafone Cash app and approve the payment',
                  'Your order will be confirmed automatically',
                ].map((step, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-white/60">
                    <span className="w-5 h-5 rounded-full bg-white/10 text-white text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">{i + 1}</span>
                    {step}
                  </li>
                ))}
              </ol>
            </div>

            {/* Merchant Number */}
            <div className="glass-panel rounded-2xl p-5 mb-6 border border-white/10">
              <p className="text-xs text-white/30 uppercase tracking-widest mb-1">JewelHub Merchant Number</p>
              <p className="font-mono text-xl font-bold text-white tracking-widest">01X-XXX-XXXX</p>
              <p className="text-xs text-white/30 mt-1">Use this number to send payment manually if needed</p>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <label className="text-xs text-white/40 uppercase tracking-widest block mb-2">Your Vodafone Cash Number</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 text-sm font-mono">+20</span>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="1XX XXX XXXX"
                    className="input-field pl-14 font-mono tracking-widest"
                    maxLength={11}
                    required
                  />
                </div>
                <p className="text-xs text-white/25 mt-2">Must be a Vodafone number registered with Vodafone Cash</p>
              </div>

              <button type="submit" className="btn-primary w-full">
                <Icon name="LockClosedIcon" size={16} />
                Send Payment Request — EGP {orderTotal.toLocaleString()}
              </button>
            </form>

            <div className="flex items-center justify-center gap-2 mt-4 text-xs text-white/25">
              <Icon name="ShieldCheckIcon" size={12} />
              <span>Secured by Vodafone Cash · SSL encrypted</span>
            </div>

            <div className="mt-6 text-center">
              <Link href="/checkout" className="text-xs text-white/30 hover:text-white/60 transition-colors underline underline-offset-2">
                ← Back to Checkout
              </Link>
            </div>
          </div>
        )}

        {step === 'confirm' && (
          <div className="glass-panel rounded-2xl p-8 text-center">
            <div className="w-14 h-14 rounded-full bg-white/5 border border-white/20 flex items-center justify-center mx-auto mb-5">
              <Icon name="DevicePhoneMobileIcon" size={24} className="text-white" />
            </div>
            <h2 className="font-display font-bold text-2xl text-white mb-3">Confirm Payment</h2>
            <p className="text-white/50 text-sm mb-2">A payment request will be sent to:</p>
            <p className="font-mono text-white font-bold text-lg mb-1">+20 {phone}</p>
            <p className="font-mono text-white/40 text-sm mb-8">Amount: EGP {orderTotal.toLocaleString()}</p>
            <div className="flex flex-col gap-3">
              <button onClick={handleConfirm} disabled={loading} className="btn-primary w-full">
                {loading ? (
                  <>
                    <Icon name="ArrowPathIcon" size={16} className="animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Icon name="CheckIcon" size={16} />
                    Confirm & Send Request
                  </>
                )}
              </button>
              <button onClick={() => setStep('form')} className="btn-outline w-full">Edit Number</button>
            </div>
          </div>
        )}

        {step === 'success' && (
          <div className="text-center">
            <div className="w-20 h-20 rounded-full bg-white/5 border-2 border-white/30 flex items-center justify-center mx-auto mb-6">
              <Icon name="CheckIcon" size={36} className="text-white" />
            </div>
            <h2 className="font-display font-bold text-3xl text-white mb-3">Payment Sent!</h2>
            <p className="text-white/50 mb-2">Payment request sent to your Vodafone Cash wallet.</p>
            <p className="text-white/30 text-sm mb-8">Please approve the request in your Vodafone Cash app to complete the order.</p>
            <div className="flex flex-col gap-3">
              <Link href="/order-confirmation" className="btn-primary justify-center">
                <Icon name="CheckCircleIcon" size={16} />
                View Order Confirmation
              </Link>
              <Link href="/track-order" className="btn-outline justify-center">
                Track My Order
              </Link>
            </div>
          </div>
        )}
      </div>
      <Footer />
    </main>
  );
}