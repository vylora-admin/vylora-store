import React from 'react';
import Header from '@/components/Header';
import RegisterForm from '@/app/register/components/RegisterForm';
import RegisterVisual from '@/app/register/components/RegisterVisual';

export default function RegisterPage() {
  return (
    <main className="bg-primary min-h-screen overflow-hidden">
      <Header />
      <div className="min-h-screen grid grid-cols-1 lg:grid-cols-2">
        <RegisterVisual />
        <RegisterForm />
      </div>
    </main>
  );
}