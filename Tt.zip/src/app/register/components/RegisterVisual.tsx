import React from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

const perks = [
{ icon: 'TagIcon', text: 'Exclusive member discounts up to 20%' },
{ icon: 'ClockIcon', text: 'Order history & easy reorders' },
{ icon: 'BellIcon', text: 'Early access to new collections' },
{ icon: 'TruckIcon', text: 'Saved addresses for faster checkout' }];


const RegisterVisual: React.FC = () => {
  return (
    <div className="hidden lg:flex relative overflow-hidden">
      <AppImage
        src="https://img.rocket.new/generatedImages/rocket_gen_img_19ee1933a-1772214266081.png"
        alt="Close-up of gold and silver jewelry pieces on dark textured surface, moody low-key studio lighting"
        fill
        priority
        className="object-cover"
        sizes="50vw" />
      
      <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/55 to-black/30" />
      <div className="absolute inset-0 bg-black/25" />

      <div className="relative z-10 flex flex-col justify-between p-12 w-full">
        {/* Top */}
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-white/60" />
          <span className="text-[11px] uppercase tracking-ultra text-white/50 font-semibold">Join JewelHub</span>
        </div>

        {/* Main content */}
        <div className="max-w-sm">
          <h2 className="text-3xl font-bold text-white tracking-tight leading-tight mb-2">
            Create your account.<br />
            <span className="text-white/45 font-light italic">Unlock exclusive perks.</span>
          </h2>
          <p className="text-sm text-white/45 font-light leading-relaxed mb-8">
            Join over 12,000 Egyptians who shop smarter with a JewelHub account.
          </p>

          <div className="space-y-4">
            {perks.map((perk) =>
            <div key={perk.text} className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg glass-panel flex items-center justify-center flex-shrink-0">
                  <Icon name={perk.icon as 'TagIcon'} size={14} className="text-white/60" />
                </div>
                <span className="text-sm text-white/60 font-light">{perk.text}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>);

};

export default RegisterVisual;