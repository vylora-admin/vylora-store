'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import Icon from '@/components/ui/AppIcon';

interface FormData {
  fullName: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
  agreeTerms: boolean;
}

interface FormErrors {
  fullName?: string;
  email?: string;
  phone?: string;
  password?: string;
  confirmPassword?: string;
  agreeTerms?: string;
}

const RegisterForm: React.FC = () => {
  const [form, setForm] = useState<FormData>({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    agreeTerms: false,
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const update = (field: keyof FormData, value: string | boolean) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const validate = (): FormErrors => {
    const errs: FormErrors = {};
    if (!form.fullName.trim()) errs.fullName = 'Full name is required';
    if (!form.email) errs.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = 'Enter a valid email';
    if (!form.phone) errs.phone = 'Phone number is required';
    else if (!/^(\+20|0)?1[0-2,5]\d{8}$/.test(form.phone.replace(/\s/g, '')))
      errs.phone = 'Enter a valid Egyptian number (e.g. 010xxxxxxxx)';
    if (!form.password) errs.password = 'Password is required';
    else if (form.password.length < 8) errs.password = 'Minimum 8 characters';
    if (!form.confirmPassword) errs.confirmPassword = 'Please confirm your password';
    else if (form.password !== form.confirmPassword) errs.confirmPassword = 'Passwords do not match';
    if (!form.agreeTerms) errs.agreeTerms = 'You must agree to the terms';
    return errs;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setErrors({});
    setLoading(true);
    // Mock submit — connect to auth backend here
    setTimeout(() => { setLoading(false); setSuccess(true); }, 1500);
  };

  if (success) {
    return (
      <div className="flex flex-col items-center justify-center px-6 md:px-12 lg:px-16 py-24 bg-primary min-h-screen lg:min-h-0">
        <div className="text-center max-w-sm">
          <div className="w-16 h-16 rounded-full bg-white/5 border border-white/15 flex items-center justify-center mx-auto mb-6">
            <Icon name="CheckIcon" size={28} className="text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Account Created!</h2>
          <p className="text-sm text-white/40 mb-6">Welcome to JewelHub. You can now sign in and start shopping.</p>
          <Link href="/login" className="btn-primary w-full justify-center py-4 rounded-xl">
            Sign In Now
          </Link>
          <Link href="/homepage" className="block text-sm text-white/35 hover:text-white/60 transition-colors mt-4">
            Continue as guest instead
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col justify-center px-6 md:px-12 lg:px-16 py-24 lg:py-8 bg-primary min-h-screen lg:min-h-0 overflow-y-auto">
      <div className="max-w-md w-full mx-auto">
        {/* Logo */}
        <Link href="/homepage" className="flex items-center gap-2.5 mb-8 group w-fit">
          <AppLogo size={34} />
          <span className="font-display font-bold text-base tracking-tight text-white">JewelHub</span>
        </Link>

        {/* Heading */}
        <div className="mb-7">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-white mb-2">Create account</h1>
          <p className="text-sm text-white/40 font-light">
            Already have an account?{' '}
            <Link href="/login" className="text-white/70 hover:text-white underline underline-offset-2 transition-colors">
              Sign in
            </Link>
          </p>
        </div>

        <form onSubmit={handleSubmit} noValidate className="space-y-5">
          {/* Full Name */}
          <div>
            <label className="block text-[11px] uppercase tracking-ultra text-white/40 mb-2">Full Name</label>
            <div className="relative">
              <input
                type="text"
                value={form.fullName}
                onChange={(e) => update('fullName', e.target.value)}
                placeholder="Nour El-Sayed"
                className={`input-field pr-10 ${errors.fullName ? 'border-red-500/60' : ''}`}
                autoComplete="name"
              />
              <Icon name="UserIcon" size={16} className="absolute right-0 top-1/2 -translate-y-1/2 text-white/20" />
            </div>
            {errors.fullName && <FieldError msg={errors.fullName} />}
          </div>

          {/* Email */}
          <div>
            <label className="block text-[11px] uppercase tracking-ultra text-white/40 mb-2">Email Address</label>
            <div className="relative">
              <input
                type="email"
                value={form.email}
                onChange={(e) => update('email', e.target.value)}
                placeholder="your@email.com"
                className={`input-field pr-10 ${errors.email ? 'border-red-500/60' : ''}`}
                autoComplete="email"
              />
              <Icon name="EnvelopeIcon" size={16} className="absolute right-0 top-1/2 -translate-y-1/2 text-white/20" />
            </div>
            {errors.email && <FieldError msg={errors.email} />}
          </div>

          {/* Phone */}
          <div>
            <label className="block text-[11px] uppercase tracking-ultra text-white/40 mb-2">
              Phone Number
              <span className="text-white/25 ml-1 normal-case">(Egyptian number)</span>
            </label>
            <div className="relative flex items-stretch">
              <div className="flex items-center px-3 border-b border-white/20 text-white/35 text-sm font-mono-custom flex-shrink-0">
                +20
              </div>
              <input
                type="tel"
                value={form.phone}
                onChange={(e) => update('phone', e.target.value)}
                placeholder="10 1234 5678"
                className={`input-field flex-1 pl-2 ${errors.phone ? 'border-red-500/60' : ''}`}
                autoComplete="tel"
              />
            </div>
            {errors.phone && <FieldError msg={errors.phone} />}
          </div>

          {/* Password */}
          <div>
            <label className="block text-[11px] uppercase tracking-ultra text-white/40 mb-2">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={form.password}
                onChange={(e) => update('password', e.target.value)}
                placeholder="Min. 8 characters"
                className={`input-field pr-10 ${errors.password ? 'border-red-500/60' : ''}`}
                autoComplete="new-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-0 top-1/2 -translate-y-1/2 text-white/20 hover:text-white/50 transition-colors"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                <Icon name={showPassword ? 'EyeSlashIcon' : 'EyeIcon'} size={16} />
              </button>
            </div>
            {errors.password && <FieldError msg={errors.password} />}
            {/* Strength hint */}
            {form.password && (
              <div className="flex gap-1 mt-2">
                {[...Array(4)].map((_, i) => (
                  <div
                    key={i}
                    className={`h-0.5 flex-1 rounded-full transition-colors duration-300 ${
                      i < (form.password.length < 6 ? 1 : form.password.length < 8 ? 2 : form.password.length < 12 ? 3 : 4)
                        ? 'bg-white/60' :'bg-white/10'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Confirm Password */}
          <div>
            <label className="block text-[11px] uppercase tracking-ultra text-white/40 mb-2">Confirm Password</label>
            <div className="relative">
              <input
                type={showConfirm ? 'text' : 'password'}
                value={form.confirmPassword}
                onChange={(e) => update('confirmPassword', e.target.value)}
                placeholder="Repeat your password"
                className={`input-field pr-10 ${errors.confirmPassword ? 'border-red-500/60' : ''}`}
                autoComplete="new-password"
              />
              <button
                type="button"
                onClick={() => setShowConfirm(!showConfirm)}
                className="absolute right-0 top-1/2 -translate-y-1/2 text-white/20 hover:text-white/50 transition-colors"
                aria-label={showConfirm ? 'Hide password' : 'Show password'}
              >
                <Icon name={showConfirm ? 'EyeSlashIcon' : 'EyeIcon'} size={16} />
              </button>
            </div>
            {errors.confirmPassword && <FieldError msg={errors.confirmPassword} />}
          </div>

          {/* Terms */}
          <div>
            <label className="flex items-start gap-3 cursor-pointer group">
              <div className="relative flex-shrink-0 mt-0.5">
                <input
                  type="checkbox"
                  checked={form.agreeTerms}
                  onChange={(e) => update('agreeTerms', e.target.checked)}
                  className="sr-only"
                />
                <div
                  className={`w-4 h-4 rounded border transition-all duration-200 flex items-center justify-center ${
                    form.agreeTerms ? 'bg-white border-white' : 'border-white/25 group-hover:border-white/50'
                  }`}
                >
                  {form.agreeTerms && <Icon name="CheckIcon" size={10} className="text-black" />}
                </div>
              </div>
              <span className="text-xs text-white/40 font-light leading-relaxed">
                I agree to JewelHub&apos;s{' '}
                <Link href="/homepage" className="text-white/70 hover:text-white underline underline-offset-1 transition-colors">Terms of Service</Link>
                {' '}and{' '}
                <Link href="/homepage" className="text-white/70 hover:text-white underline underline-offset-1 transition-colors">Privacy Policy</Link>
              </span>
            </label>
            {errors.agreeTerms && <FieldError msg={errors.agreeTerms} />}
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="w-full btn-primary justify-center py-4 rounded-xl text-sm disabled:opacity-50 disabled:cursor-not-allowed mt-1"
          >
            {loading ? (
              <>
                <Icon name="ArrowPathIcon" size={16} className="animate-spin" />
                Creating account...
              </>
            ) : (
              <>
                Create Account
                <Icon name="ArrowRightIcon" size={16} />
              </>
            )}
          </button>
        </form>

        {/* Divider */}
        <div className="flex items-center gap-4 my-5">
          <div className="flex-1 h-px bg-white/8" />
          <span className="text-[11px] text-white/25 uppercase tracking-widest">or</span>
          <div className="flex-1 h-px bg-white/8" />
        </div>

        {/* Guest */}
        <Link
          href="/homepage"
          className="w-full btn-outline justify-center py-4 rounded-xl text-sm flex items-center gap-2"
        >
          <Icon name="ShoppingBagIcon" size={16} />
          Continue as Guest
        </Link>

        {/* Trust */}
        <div className="mt-6 pt-5 border-t border-white/8 flex items-center justify-center gap-2">
          <Icon name="LockClosedIcon" size={12} className="text-white/20" />
          <span className="text-[11px] text-white/25">Your data is encrypted and never shared</span>
        </div>
      </div>
    </div>
  );
};

const FieldError: React.FC<{ msg: string }> = ({ msg }) => (
  <p className="text-[11px] text-red-400 mt-1.5 flex items-center gap-1">
    <Icon name="ExclamationCircleIcon" size={12} className="text-red-400 flex-shrink-0" />
    {msg}
  </p>
);

export default RegisterForm;
