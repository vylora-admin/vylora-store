import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const sections = [
  {
    title: '1. Information We Collect',
    content: `When you use JewelHub, we collect information you provide directly to us, including: your name, email address, phone number, delivery address, and payment information. We also automatically collect certain information about your device and how you interact with our platform, including IP address, browser type, pages visited, and purchase history.`,
  },
  {
    title: '2. How We Use Your Information',
    content: `We use the information we collect to: process and fulfill your orders; send order confirmations and shipping updates; respond to your inquiries and provide customer support; send promotional communications (with your consent); improve our products and services; prevent fraud and ensure platform security; and comply with legal obligations under Egyptian law.`,
  },
  {
    title: '3. Information Sharing',
    content: `JewelHub does not sell, trade, or rent your personal information to third parties. We may share your information with: delivery partners (Aramex, Bosta) to fulfill your orders; payment processors to complete transactions; and service providers who assist in operating our platform, all of whom are bound by confidentiality agreements. We may disclose information when required by Egyptian law or court order.`,
  },
  {
    title: '4. Data Security',
    content: `We implement industry-standard security measures to protect your personal information, including SSL encryption for all data transmission, secure payment processing, and restricted access to personal data. However, no method of transmission over the internet is 100% secure, and we cannot guarantee absolute security.`,
  },
  {
    title: '5. Cookies & Tracking',
    content: `JewelHub uses cookies and similar tracking technologies to enhance your browsing experience, remember your preferences, and analyze platform usage. You can control cookie settings through your browser preferences. Disabling cookies may affect certain features of our platform.`,
  },
  {
    title: '6. Your Rights',
    content: `You have the right to: access the personal information we hold about you; request correction of inaccurate data; request deletion of your account and associated data; opt out of marketing communications at any time; and lodge a complaint with relevant Egyptian data protection authorities. To exercise these rights, contact us at privacy@jewelhub.eg.`,
  },
  {
    title: '7. Data Retention',
    content: `We retain your personal information for as long as necessary to fulfill the purposes outlined in this policy, including for legal, accounting, or reporting requirements. Order data is retained for 7 years as required by Egyptian commercial law. You may request deletion of your account data at any time, subject to legal retention requirements.`,
  },
  {
    title: '8. Children\'s Privacy',
    content: `JewelHub is not intended for use by individuals under the age of 18. We do not knowingly collect personal information from minors. If we become aware that we have collected data from a minor, we will take immediate steps to delete that information.`,
  },
  {
    title: '9. Changes to This Policy',
    content: `We may update this Privacy Policy from time to time. We will notify you of significant changes by email or by posting a prominent notice on our platform. Your continued use of JewelHub after changes are posted constitutes acceptance of the updated policy.`,
  },
  {
    title: '10. Contact & Data Controller',
    content: `JewelHub is the data controller for personal information collected through our platform. For privacy-related inquiries, contact our Data Protection Officer at: privacy@jewelhub.eg. Mailing address: JewelHub, Cairo, Egypt. We aim to respond to all privacy requests within 30 days.`,
  },
];

export default function PrivacyPage() {
  return (
    <main className="bg-primary min-h-screen">
      <Header />
      <div className="pt-28 pb-20 px-5 md:px-8 max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <p className="section-label mb-3">Legal</p>
          <h1 className="font-display font-bold text-4xl md:text-5xl text-white tracking-tight mb-4">
            Privacy Policy
          </h1>
          <p className="text-white/40 text-sm">Last updated: April 12, 2026</p>
        </div>

        {/* Intro */}
        <div className="glass-panel rounded-2xl p-6 mb-8">
          <p className="text-white/60 text-sm leading-relaxed">
            At JewelHub, we are committed to protecting your privacy and handling your personal data with transparency and care. This Privacy Policy explains how we collect, use, and protect your information when you use our platform. We comply with applicable Egyptian data protection laws and regulations.
          </p>
        </div>

        {/* Sections */}
        <div className="space-y-6">
          {sections?.map((section) => (
            <div key={section?.title} className="border-b border-white/8 pb-6 last:border-0">
              <h2 className="font-display font-semibold text-white text-lg mb-3">{section?.title}</h2>
              <p className="text-white/50 text-sm leading-relaxed">{section?.content}</p>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </main>
  );
}
