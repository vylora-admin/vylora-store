/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: '#0A0A0A',
        secondary: '#111111',
        tertiary: '#1A1A1A',
        foreground: '#FFFFFF',
        muted: '#888888',
        'muted-light': '#AAAAAA',
        'border-subtle': 'rgba(255, 255, 255, 0.08)',
        'border-hover': 'rgba(255, 255, 255, 0.2)',
        'glass': 'rgba(255, 255, 255, 0.03)',
      },
      fontFamily: {
        display: ['DM Sans', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      fontSize: {
        'hero': 'clamp(3rem, 8vw, 7rem)',
        'hero-sm': 'clamp(2rem, 5vw, 4rem)',
        'display': 'clamp(2.5rem, 6vw, 5.5rem)',
      },
      letterSpacing: {
        'ultra': '0.25em',
      },
      borderRadius: {
        'xl2': '1.25rem',
        'xl3': '1.5rem',
      },
      backdropBlur: {
        'xs': '2px',
      },
      transitionTimingFunction: {
        'spring': 'cubic-bezier(0.34, 1.56, 0.64, 1)',
        'smooth': 'cubic-bezier(0.16, 1, 0.3, 1)',
      },
      animation: {
        'fade-in-up': 'fadeInUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards',
        'float': 'floatY 4s ease-in-out infinite',
        'border-glow': 'borderGlow 3s ease-in-out infinite',
      },
      keyframes: {
        fadeInUp: {
          from: { opacity: '0', transform: 'translateY(24px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        floatY: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-12px)' },
        },
        borderGlow: {
          '0%, 100%': { borderColor: 'rgba(255,255,255,0.08)' },
          '50%': { borderColor: 'rgba(255,255,255,0.25)' },
        },
      },
    },
  },
  plugins: [],
};